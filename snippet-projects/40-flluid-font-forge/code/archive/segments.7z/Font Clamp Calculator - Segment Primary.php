<?php

/**
 * Font Clamp Calculator - Primary
 * Version: 3.5 - Consolidated Design System
 * Priority: 5 (Loads before all segments)
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Unified CSS Controller Class
 */
class FontClampUnifiedCSS
{

    /**
     * Version for cache busting
     */
    private $version = '3.5.0';

    /**
     * Assets loaded flag
     */
    private $assets_loaded = false;

    /**
     * Constructor
     */
    public function __construct()
    {
        $this->init();
    }

    /**
     * Initialize the unified CSS
     */
    private function init()
    {
        // Only load on plugin page
        if (!$this->is_plugin_page()) {
            return;
        }

        add_action('admin_footer', [$this, 'render_unified_styles'], 5);
    }

    /**
     * Check if we're on the plugin page
     */
    private function is_plugin_page()
    {
        return isset($_GET['page']) && sanitize_text_field($_GET['page']) === 'font-clamp-calculator';
    }

    /**
     * Render unified CSS styles
     */
    public function render_unified_styles()
    {
        if ($this->assets_loaded) {
            return;
        }

?>
        <style id="font-clamp-unified-styles">
            :root {
                /* Core JimRWeb Brand Colors */
                --jimr-primary: #3C2017;
                --jimr-secondary: #5C3324;
                --jimr-text: #86400E;
                --jimr-accent: #FFD700;
                --jimr-page-bg: #E8D8C3;
                --jimr-card-bg: #F0E6DA;
                --jimr-btn-hover: #E5B929;
                --jimr-btn-text: #9C0202;
                --jimr-btn-border: #DE0B0B;
                --jimr-light: #F5F1EC;
                --jimr-shadow: rgba(60, 32, 23, 0.15);
                --jimr-overlay: rgba(232, 216, 195, 0.95);
                --jimr-secondary-hover: #dcc7a8;

                /* Extended Utility Colors for Advanced Features */
                --jimr-success: #10b981;
                --jimr-success-dark: #059669;
                --jimr-danger: #ef4444;
                --jimr-danger-dark: #dc2626;
                --jimr-info: #3b82f6;
                --jimr-info-dark: #1d4ed8;
                --jimr-warning: #f59e0b;
                --jimr-warning-dark: #d97706;

                /* Gray Scale for UI Elements */
                --jimr-gray-50: #f8fafc;
                --jimr-gray-100: #f1f5f9;
                --jimr-gray-200: #e2e8f0;
                --jimr-gray-300: #cbd5e1;
                --jimr-gray-400: #94a3b8;
                --jimr-gray-500: #64748b;
                --jimr-gray-600: #475569;
                --jimr-gray-700: #334155;
                --jimr-gray-800: #1e293b;
                --jimr-gray-900: #0f172a;

                /* Design System Utilities */
                --jimr-border-radius: 3px;
                --jimr-border-radius-lg: 5px;
                --jimr-transition: all 0.2s ease;
                --jimr-transition-slow: all 0.3s ease;
                --jimr-shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
                --jimr-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                --jimr-shadow-lg: 0 10px 25px rgba(0, 0, 0, 0.2);
                --jimr-shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);

                /* Font System */
                --jimr-font-xs: 10px;
                --jimr-font-sm: 12px;
                --jimr-font-base: 14px;
                --jimr-font-lg: 16px;
                --jimr-font-xl: 18px;
                --jimr-font-2xl: 20px;

                /* Spacing System */
                --jimr-space-1: 4px;
                --jimr-space-2: 8px;
                --jimr-space-3: 12px;
                --jimr-space-4: 16px;
                --jimr-space-5: 20px;
                --jimr-space-6: 24px;
            }

            /* GLOBAL PAGE STYLING */
            body {
                background: var(--jimr-page-bg) !important;
                color: var(--jimr-text) !important;
            }

            .wp-admin {
                background: var(--jimr-page-bg) !important;
            }

            #wpbody-content {
                background: var(--jimr-page-bg) !important;
            }

            .wrap {
                background: var(--jimr-page-bg) !important;
            }

            /* UNIFIED COMPONENT SYSTEM */

            /* Buttons - Unified System */
            .fcc-btn {
                background: var(--jimr-accent);
                color: var(--jimr-btn-text);
                border: 2px solid var(--jimr-btn-border);
                padding: var(--jimr-space-2) var(--jimr-space-4);
                border-radius: var(--jimr-border-radius);
                font-size: var(--jimr-font-sm);
                font-weight: 600;
                font-style: italic;
                text-transform: lowercase;
                letter-spacing: 0.5px;
                transition: var(--jimr-transition-slow);
                cursor: pointer;
                box-shadow: var(--jimr-shadow);
                position: relative;
                overflow: hidden;
                display: inline-flex;
                align-items: center;
                gap: var(--jimr-space-2);
                text-decoration: none;
                border: none;
            }

            .fcc-btn::before {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                width: 0;
                height: 0;
                background: rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                transform: translate(-50%, -50%);
                transition: width 0.6s, height 0.6s;
            }

            .fcc-btn:active::before {
                width: 300px;
                height: 300px;
            }

            .fcc-btn:hover {
                background: var(--jimr-btn-hover);
                transform: translateY(-2px);
                box-shadow: var(--jimr-shadow-lg);
            }

            .fcc-btn:active {
                transform: translateY(0) scale(0.98);
                box-shadow: var(--jimr-shadow);
            }

            .fcc-btn:focus {
                outline: none;
                box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.3), var(--jimr-shadow-lg);
            }

            /* Button Variants */
            .fcc-btn-primary {
                background: var(--jimr-info);
                color: white;
                border-color: var(--jimr-info);
                font-style: normal;
                text-transform: none;
                letter-spacing: normal;
            }

            .fcc-btn-primary:hover {
                background: var(--jimr-info-dark);
                border-color: var(--jimr-info-dark);
            }

            .fcc-btn-secondary {
                background: var(--jimr-secondary);
                color: white;
                border-color: var(--jimr-primary);
                font-style: normal;
                text-transform: none;
                letter-spacing: normal;
            }

            .fcc-btn-secondary:hover {
                background: var(--jimr-primary);
                border-color: var(--jimr-gray-700);
            }

            .fcc-btn-success {
                background: var(--jimr-success);
                color: white;
                border-color: var(--jimr-success);
                font-style: normal;
                text-transform: none;
                letter-spacing: normal;
            }

            .fcc-btn-success:hover {
                background: var(--jimr-success-dark);
                border-color: var(--jimr-success-dark);
            }

            .fcc-btn-danger {
                background: var(--jimr-danger);
                color: white;
                border-color: var(--jimr-danger-dark);
                font-style: normal;
                text-transform: none;
                letter-spacing: normal;
            }

            .fcc-btn-danger:hover {
                background: var(--jimr-danger-dark);
                border-color: #991b1b;
            }

            .fcc-btn-ghost {
                background: var(--jimr-gray-500);
                color: white;
                border-color: var(--jimr-gray-600);
                font-style: normal;
                text-transform: none;
                letter-spacing: normal;
            }

            .fcc-btn-ghost:hover {
                background: var(--jimr-gray-700);
                border-color: var(--jimr-gray-800);
            }

            /* Input Fields - Unified System */
            .fcc-input,
            .component-input,
            .component-select {
                height: 40px;
                padding: 10px 12px;
                border: 2px solid var(--jimr-secondary);
                border-radius: var(--jimr-border-radius);
                font-size: var(--jimr-font-base);
                background: white;
                color: var(--jimr-text);
                transition: var(--jimr-transition-slow);
                box-sizing: border-box;
                margin: 0;
                width: 100%;
            }

            .fcc-input:focus,
            .component-input:focus,
            .component-select:focus {
                outline: none;
                border-color: var(--jimr-accent);
                box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.2), var(--jimr-shadow);
                background: var(--jimr-light);
                transform: translateY(-2px);
            }

            .fcc-input.error {
                border-color: var(--jimr-danger);
                background-color: rgba(239, 68, 68, 0.05);
            }

            /* Select Dropdown Styling */
            .component-select,
            select.fcc-input {
                cursor: pointer;
                appearance: none;
                background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%235C3324' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6,9 12,15 18,9'%3e%3c/polyline%3e%3c/svg%3e");
                background-repeat: no-repeat;
                background-position: right 8px center;
                background-size: 16px;
                padding-right: 32px;
            }

            /* Labels - Unified System */
            label,
            .component-label,
            .fcc-label {
                color: var(--jimr-text);
                font-weight: 500;
                font-size: var(--jimr-font-sm);
                line-height: 1.3;
                margin-bottom: var(--jimr-space-2);
                display: block;
            }

            /* LAYOUT COMPONENTS */

            /* Main Container */
            .font-clamp-container {
                max-width: 1280px;
                margin: 0 auto;
                background: var(--jimr-card-bg);
                border-radius: var(--jimr-border-radius-lg);
                box-shadow: var(--jimr-shadow-xl);
                overflow: hidden;
                border: 2px solid var(--jimr-primary);
                opacity: 0;
                visibility: hidden;
                transition: opacity 0.3s ease, visibility 0.3s ease;
            }

            .font-clamp-container.ready {
                opacity: 1;
                visibility: visible;
            }

            .font-clamp-container * {
                box-sizing: border-box;
            }

            /* Panels */
            .fcc-panel {
                background: var(--jimr-light);
                padding: var(--jimr-space-5);
                border-radius: var(--jimr-border-radius-lg);
                border: 2px solid var(--jimr-secondary);
                box-shadow: var(--jimr-shadow-lg);
                transition: var(--jimr-transition);
            }

            .fcc-panel:hover {
                box-shadow: var(--jimr-shadow-xl);
                transform: translateY(-2px);
            }

            /* Grid Layouts */
            .fcc-main-grid {
                display: grid;
                grid-template-columns: 1fr 1.2fr;
                gap: var(--jimr-space-6);
                margin-bottom: var(--jimr-space-6);
            }

            @media (max-width: 1024px) {
                .fcc-main-grid {
                    grid-template-columns: 1fr;
                    gap: var(--jimr-space-4);
                }
            }

            .fcc-preview-enhanced {
                background: var(--jimr-light);
                padding: var(--jimr-space-5);
                border-radius: var(--jimr-border-radius-lg);
                border: 2px solid var(--jimr-secondary);
                box-shadow: var(--jimr-shadow-lg);
                margin-top: var(--jimr-space-4);
                transition: var(--jimr-transition);
            }

            .fcc-preview-enhanced:hover {
                box-shadow: var(--jimr-shadow-xl);
                transform: translateY(-2px);
            }

            .fcc-preview-header-row {
                text-align: left;
                margin-bottom: var(--jimr-space-5);
                border-bottom: 2px solid var(--jimr-secondary);
                padding-bottom: var(--jimr-space-3);
            }

            .fcc-preview-header-row h2 {
                color: var(--jimr-primary) !important;
                font-family: 'Georgia', serif !important;
                font-size: var(--jimr-font-2xl) !important;
                font-weight: 700 !important;
                margin: 0 !important;
                text-shadow: 1px 1px 2px var(--jimr-shadow) !important;
                border: none !important;
            }

            .fcc-preview-grid {
                display: grid;
                grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
                gap: var(--jimr-space-6);
                align-items: start;
            }

            .fcc-preview-column {
                display: flex;
                flex-direction: column;
                gap: var(--jimr-space-3);
            }

            .fcc-preview-column-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: var(--jimr-space-2);
                padding: var(--jimr-space-2) var(--jimr-space-3);
                background: rgba(92, 51, 36, 0.1);
                border-radius: var(--jimr-border-radius);
                border: 1px solid var(--jimr-secondary);
            }

            .fcc-preview-column-header h3 {
                color: var(--jimr-secondary) !important;
                font-size: var(--jimr-font-lg) !important;
                font-weight: 600 !important;
                margin: 0 !important;
                line-height: 1.2 !important;
            }

            /* Root size indicator badges */
            .fcc-scale-indicator {
                background: var(--jimr-secondary);
                color: #FAF9F6;
                border: 1px solid var(--jimr-primary);
                padding: var(--jimr-space-1) var(--jimr-space-3);
                border-radius: var(--jimr-border-radius);
                font-size: var(--jimr-font-sm);
                font-weight: 600;
                font-style: normal;
                display: inline-block;
                box-shadow: var(--jimr-shadow-sm);
                min-width: 60px;
                text-align: center;
                line-height: 1.2;
            }

            /* Preview content containers */
            .fcc-preview-column #preview-min-container,
            .fcc-preview-column #preview-max-container {
                background: white !important;
                border-radius: var(--jimr-border-radius) !important;
                padding: var(--jimr-space-4) !important;
                border: 2px solid var(--jimr-secondary) !important;
                min-height: 320px !important;
                box-shadow: inset 0 2px 4px var(--jimr-shadow) !important;
                width: 100%;
                max-width: 100%;
                overflow: hidden;
            }

            /* Preview row styling */
            .preview-row {
                margin-bottom: var(--jimr-space-1) !important;
                padding: var(--jimr-space-2) var(--jimr-space-3) !important;
                border-radius: var(--jimr-border-radius) !important;
                transition: var(--jimr-transition) !important;
                cursor: pointer !important;
                border: 1px solid transparent !important;
            }

            .preview-row:hover {
                background-color: rgba(59, 130, 246, 0.05) !important;
                border-color: rgba(59, 130, 246, 0.2) !important;
                transform: translateX(2px) !important;
            }

            .preview-row:last-child {
                margin-bottom: 0 !important;
            }

            /* Responsive design - stack on mobile */
            @media (max-width: 1024px) {
                .fcc-preview-grid {
                    grid-template-columns: 1fr;
                    gap: var(--jimr-space-4);
                }

                .fcc-preview-column-header {
                    flex-direction: column;
                    gap: var(--jimr-space-2);
                    text-align: center;
                }

                .fcc-preview-column-header h3 {
                    font-size: var(--jimr-font-base) !important;
                }

                .fcc-scale-indicator {
                    align-self: center;
                }
            }

            /* ADVANCED FEATURES STYLES */

            /* Tables */
            .font-table {
                border: none !important;
                border-collapse: collapse;
                table-layout: fixed;
                width: 100%;
                background: white;
                border-radius: var(--jimr-border-radius);
                overflow: hidden;
                box-shadow: var(--jimr-shadow);
            }

            .font-table th,
            .font-table td {
                border: none !important;
                padding: var(--jimr-space-2) var(--jimr-space-2);
                overflow: hidden;
                text-overflow: ellipsis;
                font-size: var(--jimr-font-sm);
                line-height: 1.3;
            }

            .font-table th {
                font-size: var(--jimr-font-xs);
                font-weight: 600;
                background-color: var(--jimr-gray-100) !important;
                color: var(--jimr-gray-700);
                text-transform: uppercase;
                letter-spacing: 0.05em;
                vertical-align: top;
                border-bottom: 2px solid var(--jimr-gray-200) !important;
            }

            .font-table tbody tr:not(:last-child) td {
                border-bottom: 1px solid var(--jimr-gray-100) !important;
            }

            .font-table td:hover {
                background-color: rgba(59, 130, 246, 0.05) !important;
            }

            /* Drag and Drop Styles */
            .size-row {
                transition: var(--jimr-transition);
                cursor: move;
                height: 32px;
                border-left: 3px solid transparent;
            }

            .size-row:nth-child(even) {
                background-color: var(--jimr-gray-50);
            }

            .size-row:nth-child(odd) {
                background-color: #ffffff;
            }

            .size-row:hover {
                background-color: var(--jimr-gray-200) !important;
                border-left-color: var(--jimr-info);
                transform: translateX(2px);
            }

            .size-row.selected {
                background-color: #dbeafe !important;
                border-left-color: var(--jimr-info-dark);
                box-shadow: inset 0 0 0 1px var(--jimr-info);
            }

            .size-row.dragging {
                opacity: 0.7 !important;
                background-color: #e0f2fe !important;
                border-left: 4px solid var(--jimr-info) !important;
                box-shadow: var(--jimr-shadow-lg) !important;
            }

            .drag-over {
                border-top: 3px solid var(--jimr-info) !important;
                background-color: #f0f9ff !important;
                box-shadow: 0 0 0 2px rgba(59, 130, 246, 0.2) !important;
                transform: translateY(-1px) !important;
                position: relative !important;
            }

            .drag-over::before {
                content: '';
                position: absolute;
                top: -3px;
                left: 0;
                right: 0;
                height: 3px;
                background: linear-gradient(90deg, var(--jimr-info), transparent, var(--jimr-info));
                animation: pulse-line 1s ease-in-out infinite alternate;
            }

            @keyframes pulse-line {
                0% {
                    opacity: 0.5;
                }

                100% {
                    opacity: 1;
                }
            }

            .drag-handle {
                font-family: monospace;
                user-select: none;
                color: var(--jimr-gray-400);
                transition: var(--jimr-transition);
                padding: var(--jimr-space-1);
                border-radius: 3px;
                cursor: grab;
            }

            .drag-handle:hover {
                color: var(--jimr-gray-700);
                background-color: rgba(59, 130, 246, 0.1);
                cursor: grab;
            }

            .drag-handle:active {
                cursor: grabbing;
            }

            .size-row:hover .drag-handle {
                color: var(--jimr-info);
            }

            /* Modal Styles */
            .fcc-modal {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: rgba(0, 0, 0, 0.5);
                z-index: 9999;
                display: none;
                align-items: center;
                justify-content: center;
                backdrop-filter: blur(2px);
            }

            .fcc-modal.show {
                display: flex;
            }

            .fcc-modal-dialog {
                background: white;
                border-radius: calc(var(--jimr-border-radius) + 2px);
                padding: 0;
                width: 400px;
                max-width: 90vw;
                max-height: 90vh;
                box-shadow: var(--jimr-shadow-xl);
                border: 3px solid var(--jimr-secondary);
                transform: scale(0.9);
                transition: transform 0.3s ease;
                overflow: hidden;
            }

            .fcc-modal.show .fcc-modal-dialog {
                transform: scale(1);
            }

            .fcc-modal-header {
                background: var(--jimr-secondary-hover);
                padding: var(--jimr-space-4) var(--jimr-space-5);
                border-bottom: 1px solid var(--jimr-secondary);
                cursor: grab;
                font-size: var(--jimr-font-xl);
                font-weight: 600;
                user-select: none;
                position: relative;
            }

            .fcc-modal-header:hover {
                background: var(--jimr-secondary-hover);
            }

            .fcc-modal-header:active {
                cursor: grabbing;
            }

            .fcc-modal-close {
                position: absolute;
                top: 50%;
                right: var(--jimr-space-4);
                transform: translateY(-50%);
                background: none;
                border: none;
                font-size: 24px;
                cursor: pointer;
                color: var(--jimr-gray-500);
                transition: var(--jimr-transition);
                width: 32px;
                height: 32px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: var(--jimr-border-radius);
            }

            .fcc-modal-close:hover {
                color: var(--jimr-gray-700);
                background: rgba(0, 0, 0, 0.1);
            }

            .fcc-modal-content {
                padding: var(--jimr-space-5);
            }

            /* Form Groups */
            .fcc-form-group {
                margin-bottom: var(--jimr-space-4);
            }

            .fcc-form-group:last-child {
                margin-bottom: 0;
            }

            .fcc-btn-group {
                display: flex;
                gap: var(--jimr-space-2);
                justify-content: flex-end;
                margin-top: var(--jimr-space-5);
            }

            /* SPECIALIZED COMPONENTS */

            /* Loading States */
            .fcc-loading {
                opacity: 0.6;
                pointer-events: none;
                position: relative;
            }

            .fcc-loading::after {
                content: "";
                position: absolute;
                top: 50%;
                left: 50%;
                width: 20px;
                height: 20px;
                margin: -10px 0 0 -10px;
                border: 2px solid var(--jimr-gray-200);
                border-top-color: var(--jimr-info);
                border-radius: 50%;
                animation: fcc-spin 1s linear infinite;
            }

            @keyframes fcc-spin {
                to {
                    transform: rotate(360deg);
                }
            }

            /* Loading Screen */
            .fcc-loading-screen {
                position: fixed;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: var(--jimr-overlay);
                backdrop-filter: blur(5px);
                z-index: 9999;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: opacity 0.5s ease, visibility 0.5s ease;
            }

            .fcc-loading-screen.hidden {
                opacity: 0;
                visibility: hidden;
                pointer-events: none;
            }

            .fcc-loading-content {
                text-align: center;
                max-width: 420px;
                padding: 50px;
                background: var(--jimr-card-bg);
                border-radius: var(--jimr-border-radius-lg);
                box-shadow: var(--jimr-shadow-xl);
                border: 3px solid var(--jimr-primary);
                position: relative;
            }

            .fcc-loading-content::before {
                content: '';
                position: absolute;
                top: -3px;
                left: -3px;
                right: -3px;
                bottom: -3px;
                background: linear-gradient(45deg, var(--jimr-accent), var(--jimr-btn-hover));
                border-radius: 15px;
                z-index: -1;
                animation: fcc-border-glow 2s ease-in-out infinite alternate;
            }

            @keyframes fcc-border-glow {
                0% {
                    opacity: 0.5;
                }

                100% {
                    opacity: 1;
                }
            }

            .fcc-loading-spinner {
                width: 60px;
                height: 60px;
                border: 5px solid var(--jimr-light);
                border-top: 5px solid var(--jimr-accent);
                border-right: 5px solid var(--jimr-btn-hover);
                border-radius: 50%;
                animation: fcc-spin 1.2s linear infinite;
                margin: 0 auto 25px;
                box-shadow: var(--jimr-shadow);
            }

            .fcc-loading-content h2 {
                color: var(--jimr-primary);
                margin: 0 0 12px 0;
                font-size: 26px;
                font-weight: 700;
                font-family: 'Georgia', serif;
                text-shadow: 1px 1px 2px var(--jimr-shadow);
            }

            .fcc-loading-content p {
                color: var(--jimr-text);
                margin: 0 0 25px 0;
                font-size: 15px;
                font-weight: 500;
            }

            .fcc-loading-progress {
                width: 100%;
                height: 6px;
                background: var(--jimr-light);
                border-radius: 3px;
                overflow: hidden;
                border: 1px solid var(--jimr-primary);
            }

            .fcc-progress-bar {
                height: 100%;
                background: linear-gradient(90deg, var(--jimr-accent), var(--jimr-btn-hover), var(--jimr-accent));
                width: 0%;
                border-radius: 2px;
                animation: fcc-progress 3s ease-in-out infinite;
                box-shadow: 0 0 10px rgba(255, 215, 0, 0.4);
            }

            @keyframes fcc-progress {
                0% {
                    width: 0%;
                }

                50% {
                    width: 70%;
                }

                100% {
                    width: 100%;
                }
            }

            /* Collapsible Info Sections */
            .fcc-info-toggle-section {
                margin-bottom: var(--jimr-space-6);
                border: 2px solid var(--jimr-secondary);
                border-radius: var(--jimr-border-radius-lg);
                overflow: hidden;
                background: linear-gradient(135deg, var(--jimr-light), var(--jimr-card-bg));
                box-shadow: var(--jimr-shadow);
            }

            .fcc-info-toggle {
                width: 100%;
                background: var(--jimr-secondary);
                color: #FAF9F6 !important;
                border: none;
                padding: var(--jimr-space-4) var(--jimr-space-5);
                cursor: pointer;
                display: flex;
                justify-content: space-between;
                align-items: center;
                font-size: var(--jimr-font-lg);
                font-weight: 600;
                transition: var(--jimr-transition-slow);
                text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
            }

            .fcc-info-toggle:hover {
                background: var(--jimr-primary);
                color: #FAF9F6 !important;
                transform: translateY(-1px);
            }

            .fcc-toggle-icon {
                transition: transform 0.3s ease;
                font-size: var(--jimr-font-base);
                color: #FAF9F6 !important;
            }

            .fcc-info-toggle.expanded .fcc-toggle-icon {
                transform: rotate(180deg);
            }

            .fcc-info-content {
                max-height: 0;
                overflow: hidden;
                transition: max-height 0.4s ease, padding 0.4s ease;
                background: var(--jimr-light);
                color: #FAF9F6;
            }

            .fcc-info-content.expanded {
                max-height: 500px;
                padding: var(--jimr-space-5);
            }

            /* Typography Overrides */
            h1 {
                color: var(--jimr-primary) !important;
                font-family: 'Georgia', serif;
                text-shadow: 1px 1px 2px var(--jimr-shadow);
            }

            h2 {
                color: var(--jimr-primary) !important;
                font-family: 'Georgia', serif;
                border-bottom-color: var(--jimr-secondary) !important;
                text-shadow: 1px 1px 2px var(--jimr-shadow);
                font-size: var(--jimr-font-2xl);
                margin: 0 0 var(--jimr-space-5) 0;
                border-bottom: 2px solid var(--jimr-secondary);
                padding-bottom: var(--jimr-space-2);
            }

            h3 {
                color: var(--jimr-secondary) !important;
                font-weight: 600;
            }

            p,
            span {
                color: var(--jimr-text) !important;
            }

            a {
                color: var(--jimr-btn-border) !important;
                text-decoration: none !important;
                font-weight: 600 !important;
                transition: var(--jimr-transition) !important;
                text-shadow: none !important;
            }

            a:hover {
                color: #991b1b !important;
                text-shadow: 0 0 8px rgba(222, 11, 11, 0.3) !important;
                text-decoration: underline !important;
            }

            /* HEADER LAYOUT COMPONENTS */

            /* Preview Font Input Layout */
            .fcc-font-input {
                display: flex;
                align-items: center;
                gap: var(--jimr-space-3);
            }

            .fcc-font-input label {
                white-space: nowrap;
                margin-bottom: 0;
                font-size: var(--jimr-font-sm);
                font-weight: 500;
                color: var(--jimr-text);
            }

            .fcc-font-input input {
                width: 200px;
                margin-bottom: 0;
            }

            .fcc-font-input span {
                font-size: var(--jimr-font-sm);
                color: var(--jimr-gray-500);
                font-style: italic;
            }

            /* Autosave Layout */
            .fcc-autosave-flex {
                display: flex;
                align-items: center;
                gap: var(--jimr-space-4);
            }

            .fcc-autosave-flex label {
                display: flex;
                align-items: center;
                gap: var(--jimr-space-1);
                margin-bottom: 0;
                cursor: pointer;
            }

            .fcc-autosave-flex input[type="checkbox"] {
                margin: 0;
                border-radius: 2px;
            }

            .fcc-autosave-flex span {
                font-size: var(--jimr-font-sm);
                color: var(--jimr-text);
            }

            /* TOOLTIP SYSTEM */
            [data-tooltip] {
                position: relative;
                cursor: help;
            }

            [data-tooltip]:hover::after {
                content: attr(data-tooltip);
                position: absolute;
                bottom: 100%;
                left: 50%;
                transform: translateX(-50%);
                background: var(--jimr-gray-900);
                color: white;
                padding: var(--jimr-space-2) var(--jimr-space-3);
                border-radius: var(--jimr-border-radius);
                font-size: var(--jimr-font-xs);
                white-space: nowrap;
                z-index: 1000;
                margin-bottom: var(--jimr-space-1);
                box-shadow: var(--jimr-shadow);
                animation: tooltip-fade-in 0.2s ease;
            }

            [data-tooltip]:hover::before {
                content: '';
                position: absolute;
                bottom: 100%;
                left: 50%;
                transform: translateX(-50%);
                border: 4px solid transparent;
                border-top-color: var(--jimr-gray-900);
                z-index: 1001;
            }

            @keyframes tooltip-fade-in {
                from {
                    opacity: 0;
                    transform: translateX(-50%) translateY(4px);
                }

                to {
                    opacity: 1;
                    transform: translateX(-50%) translateY(0);
                }
            }

            /* Tooltip variants */
            [data-tooltip-position="right"]:hover::after {
                left: 100%;
                top: 50%;
                bottom: auto;
                transform: translateY(-50%);
                margin-left: var(--jimr-space-1);
                margin-bottom: 0;
            }

            [data-tooltip-position="right"]:hover::before {
                left: 100%;
                top: 50%;
                bottom: auto;
                transform: translateY(-50%);
                border: 4px solid transparent;
                border-right-color: var(--jimr-gray-900);
                border-top-color: transparent;
            }

            /* SPECIFIC COMPONENTS */

            /* Font Units Selector */
            .font-units-section {
                margin-bottom: var(--jimr-space-5);
            }

            .font-units-label {
                display: block;
                font-size: var(--jimr-font-sm);
                font-weight: 500;
                color: var(--jimr-text);
                margin-bottom: var(--jimr-space-1);
            }

            .font-units-buttons {
                display: flex;
                border-radius: var(--jimr-border-radius-lg);
                overflow: hidden;
                border: 2px solid var(--jimr-primary);
                box-shadow: var(--jimr-shadow);
            }

            .unit-button {
                background: var(--jimr-accent);
                color: #9C0202;
                border: none;
                width: 50%;
                padding: var(--jimr-space-2);
                text-align: center;
                font-size: var(--jimr-font-base);
                font-weight: 500;
                cursor: pointer;
                transition: var(--jimr-transition-slow);
            }

            .unit-button.active {
                background: var(--jimr-secondary);
                color: #FAF9F6;
                font-weight: 700;
            }

            .unit-button:hover {
                background: var(--jimr-btn-hover);
                transform: translateY(-1px);
                box-shadow: var(--jimr-shadow);
            }

            /* Tab System */
            .fcc-tabs {
                display: flex;
                gap: var(--jimr-space-1);
                background: var(--jimr-primary);
                padding: 3px;
                border-radius: var(--jimr-border-radius-lg);
                box-shadow: inset 0 2px 4px rgba(0, 0, 0, 0.1);
            }

            .tab-button {
                background: var(--jimr-accent);
                color: var(--jimr-btn-text);
                border: 2px solid var(--jimr-btn-border);
                transition: var(--jimr-transition-slow);
                cursor: pointer;
                font-weight: 600;
                text-shadow: none;
                position: relative;
                overflow: hidden;
            }

            .tab-button:hover {
                background: var(--jimr-btn-hover);
                color: var(--jimr-btn-text);
                border-color: var(--jimr-btn-border);
                transform: translateY(-1px);
                box-shadow: var(--jimr-shadow);
            }

            .tab-button.active {
                background: var(--jimr-secondary) !important;
                color: #FAF9F6 !important;
                border-color: var(--jimr-primary) !important;
                font-weight: 700 !important;
                box-shadow: 0 0 15px rgba(92, 51, 36, 0.4) !important;
            }

            .tab-button.active::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
                animation: shimmer 2s infinite;
            }

            @keyframes shimmer {
                0% {
                    transform: translateX(-100%);
                }

                100% {
                    transform: translateX(100%);
                }
            }

            /* Grid Items */
            .grid-item {
                display: flex;
                flex-direction: column;
                gap: 2px;
            }

            /* Autosave Status */
            .autosave-status {
                display: inline-flex;
                align-items: center;
                gap: var(--jimr-space-2);
                font-size: 0.8rem;
                padding: var(--jimr-space-1) var(--jimr-space-3);
                border-radius: var(--jimr-border-radius);
                transition: var(--jimr-transition-slow);
                font-weight: 500;
                border: 1px solid transparent;
            }

            .autosave-status.saving {
                background: linear-gradient(135deg, var(--jimr-accent), var(--jimr-btn-hover));
                color: var(--jimr-btn-text);
                border-color: var(--jimr-btn-border);
                animation: pulse 1.5s ease-in-out infinite;
            }

            .autosave-status.saved {
                background: linear-gradient(135deg, var(--jimr-success), var(--jimr-success-dark));
                color: white;
                border-color: #15803d;
            }

            .autosave-status.error {
                background: linear-gradient(135deg, var(--jimr-btn-border), var(--jimr-danger));
                color: white;
                border-color: #991b1b;
            }

            .autosave-status.idle {
                background: var(--jimr-card-bg);
                color: var(--jimr-text);
                border-color: var(--jimr-secondary);
            }

            @keyframes pulse {

                0%,
                100% {
                    opacity: 1;
                }

                50% {
                    opacity: 0.7;
                }
            }

            /* Spinner */
            .spinner {
                width: 14px;
                height: 14px;
                border: 2px solid transparent;
                border-top: 2px solid currentColor;
                border-right: 2px solid currentColor;
                border-radius: 50%;
                animation: fcc-spin 1s linear infinite;
            }

            /* Utility Classes */
            .fcc-error {
                border: 2px solid var(--jimr-danger) !important;
                background: rgba(239, 68, 68, 0.1) !important;
            }

            .fcc-success {
                border: 2px solid var(--jimr-success) !important;
                background: rgba(16, 185, 129, 0.1) !important;
            }

            .fcc-hidden {
                display: none !important;
            }

            /* RESPONSIVE DESIGN */
            @media (max-width: 768px) {
                .fcc-main-grid {
                    grid-template-columns: 1fr;
                    gap: var(--jimr-space-4);
                }

                .fcc-tabs {
                    justify-content: center;
                }

                .fcc-info-content div[style*="grid-template-columns: 1fr 1fr"] {
                    grid-template-columns: 1fr !important;
                    gap: var(--jimr-space-4) !important;
                }
            }

            /* ACCESSIBILITY */
            @media (prefers-reduced-motion: reduce) {
                * {
                    animation-duration: 0.01ms !important;
                    animation-iteration-count: 1 !important;
                    transition-duration: 0.01ms !important;
                }
            }

            @media (prefers-contrast: high) {

                .fcc-btn,
                .fcc-input {
                    border-width: 3px !important;
                }
            }

            /* Focus visible for keyboard navigation */
            .fcc-btn:focus-visible,
            .fcc-input:focus-visible {
                outline: 2px solid var(--jimr-accent) !important;
                outline-offset: 2px !important;
            }

            /* Preview row selected state */
            .preview-row.selected {
                background-color: #dbeafe !important;
                border-left: 4px solid var(--jimr-info) !important;
                box-shadow: inset 0 0 0 1px var(--jimr-info) !important;
                transform: translateX(2px) !important;
            }

            /* Preview row hover enhancement */
            .preview-row:hover {
                background-color: rgba(59, 130, 246, 0.1) !important;
                border-left: 2px solid var(--jimr-info) !important;
                transform: translateX(1px) !important;
            }

            /* Smooth transitions for preview rows */
            .preview-row {
                transition: background-color 0.2s ease, transform 0.2s ease, border-left 0.2s ease !important;
                border-left: 2px solid transparent !important;
            }
        </style>
<?php

        $this->assets_loaded = true;
    }
}

// Initialize the unified CSS
if (is_admin()) {
    new FontClampUnifiedCSS();
}
?>