<?php

/**
 * Font Clamp Calculator - Segment A (Foundation) - COMPLETE WITH ALL METHODS
 * Version: 3.5 - Foundation Layer with Complete Constant System
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class FontClampCalculator
{
    // Configuration Constants
    const VERSION = '3.5';
    const PLUGIN_SLUG = 'font-clamp-calculator';
    const NONCE_ACTION = 'font_clamp_nonce';

    // Validation Ranges
    const MIN_ROOT_SIZE_RANGE = [1, 100];
    const VIEWPORT_RANGE = [200, 5000];
    const LINE_HEIGHT_RANGE = [0.8, 3.0];
    const SCALE_RANGE = [1.0, 3.0];

    // Default Values - PRIMARY CONSTANTS
    const DEFAULT_MIN_ROOT_SIZE = 16;
    const DEFAULT_MAX_ROOT_SIZE = 20;
    const DEFAULT_MIN_VIEWPORT = 375;
    const DEFAULT_MAX_VIEWPORT = 1620;
    const DEFAULT_LINE_HEIGHT = 1.4;
    const DEFAULT_MIN_SCALE = 1.125;
    const DEFAULT_MAX_SCALE = 1.333;
    
    // FIXED: Additional line height constants for different text types
    const DEFAULT_HEADING_LINE_HEIGHT = 1.2;  // For h1, h2, h3, large text
    const DEFAULT_BODY_LINE_HEIGHT = 1.4;     // For p, smaller text
    
    // FIXED: Browser and system constants
    const BROWSER_DEFAULT_FONT_SIZE = 16;     // Standard browser default
    const CSS_UNIT_CONVERSION_BASE = 16;      // For rem/px conversions

    // Valid Options
    const VALID_UNITS = ['px', 'rem'];
    const VALID_TABS = ['class', 'vars', 'tag'];

    // WordPress Options Keys
    const OPTION_SETTINGS = 'font_clamp_settings';
    const OPTION_CLASS_SIZES = 'font_clamp_class_sizes';
    const OPTION_VARIABLE_SIZES = 'font_clamp_variable_sizes';
    const OPTION_TAG_SIZES = 'font_clamp_tag_sizes';

    // Class properties
    private $default_settings;
    private $default_class_sizes;
    private $default_variable_sizes;
    private $default_tag_sizes;

    /**
     * Constructor - Initialize the foundation
     */
    public function __construct()
    {
        $this->init_defaults();
        $this->init_hooks();
    }

    /**
     * Initialize default values using factory methods
     */
    private function init_defaults()
    {
        $this->default_settings = $this->create_default_settings();
        $this->default_class_sizes = $this->create_default_sizes('class');
        $this->default_variable_sizes = $this->create_default_sizes('vars');
        $this->default_tag_sizes = $this->create_default_sizes('tags');
    }

    /**
     * Create default settings array
     * @return array Default settings
     */
    private function create_default_settings()
    {
        return [
            'minRootSize' => self::DEFAULT_MIN_ROOT_SIZE,
            'maxRootSize' => self::DEFAULT_MAX_ROOT_SIZE,
            'minViewport' => self::DEFAULT_MIN_VIEWPORT,
            'maxViewport' => self::DEFAULT_MAX_VIEWPORT,
            'unitType' => 'px',
            'selectedClassSizeId' => 5,
            'selectedVariableSizeId' => 5,
            'selectedTagSizeId' => 1,
            'activeTab' => 'class',
            'previewFontUrl' => '',
            'minScale' => self::DEFAULT_MIN_SCALE,
            'maxScale' => self::DEFAULT_MAX_SCALE,
            'autosaveEnabled' => true,
            'classBaseValue' => 'medium',
            'varsBaseValue' => '--fs-md',
            'tagBaseValue' => 'p'
        ];
    }

    /**
     * FIXED: Create default sizes array for specified type - NO MORE MAGIC NUMBERS
     * @param string $type Type of sizes ('class', 'vars', 'tags')
     * @return array Default sizes array
     */
    private function create_default_sizes($type)
    {
        $configs = [
            'class' => [
                ['id' => 1, 'name' => 'xxxlarge', 'lineHeight' => self::DEFAULT_HEADING_LINE_HEIGHT],
                ['id' => 2, 'name' => 'xxlarge', 'lineHeight' => self::DEFAULT_HEADING_LINE_HEIGHT],
                ['id' => 3, 'name' => 'xlarge', 'lineHeight' => self::DEFAULT_HEADING_LINE_HEIGHT],
                ['id' => 4, 'name' => 'large', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 5, 'name' => 'medium', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 6, 'name' => 'small', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 7, 'name' => 'xsmall', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 8, 'name' => 'xxsmall', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT]
            ],
            'vars' => [
                ['id' => 1, 'name' => '--fs-xxxl', 'lineHeight' => self::DEFAULT_HEADING_LINE_HEIGHT],
                ['id' => 2, 'name' => '--fs-xxl', 'lineHeight' => self::DEFAULT_HEADING_LINE_HEIGHT],
                ['id' => 3, 'name' => '--fs-xl', 'lineHeight' => self::DEFAULT_HEADING_LINE_HEIGHT],
                ['id' => 4, 'name' => '--fs-lg', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 5, 'name' => '--fs-md', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 6, 'name' => '--fs-sm', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 7, 'name' => '--fs-xs', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 8, 'name' => '--fs-xxs', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT]
            ],
            'tags' => [
                ['id' => 1, 'name' => 'h1', 'lineHeight' => self::DEFAULT_HEADING_LINE_HEIGHT],
                ['id' => 2, 'name' => 'h2', 'lineHeight' => self::DEFAULT_HEADING_LINE_HEIGHT],
                ['id' => 3, 'name' => 'h3', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 4, 'name' => 'h4', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 5, 'name' => 'h5', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 6, 'name' => 'h6', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT],
                ['id' => 7, 'name' => 'p', 'lineHeight' => self::DEFAULT_BODY_LINE_HEIGHT]
            ]
        ];

        if (!isset($configs[$type])) {
            error_log("Font Clamp: Invalid size type: {$type}");
            return [];
        }

        $config = $configs[$type];
        $property_name = $this->get_size_property_name($type);

        return array_map(function ($item) use ($property_name) {
            return [
                'id' => $item['id'],
                $property_name => $item['name'],
                'lineHeight' => $item['lineHeight']
            ];
        }, $config);
    }

    /**
     * NEW: Get all constants as array for JavaScript access
     * @return array All constants for frontend use
     */
    public function get_all_constants()
    {
        return [
            // Primary defaults
            'DEFAULT_MIN_ROOT_SIZE' => self::DEFAULT_MIN_ROOT_SIZE,
            'DEFAULT_MAX_ROOT_SIZE' => self::DEFAULT_MAX_ROOT_SIZE,
            'DEFAULT_MIN_VIEWPORT' => self::DEFAULT_MIN_VIEWPORT,
            'DEFAULT_MAX_VIEWPORT' => self::DEFAULT_MAX_VIEWPORT,
            'DEFAULT_LINE_HEIGHT' => self::DEFAULT_LINE_HEIGHT,
            'DEFAULT_MIN_SCALE' => self::DEFAULT_MIN_SCALE,
            'DEFAULT_MAX_SCALE' => self::DEFAULT_MAX_SCALE,
            
            // Line height variants
            'DEFAULT_HEADING_LINE_HEIGHT' => self::DEFAULT_HEADING_LINE_HEIGHT,
            'DEFAULT_BODY_LINE_HEIGHT' => self::DEFAULT_BODY_LINE_HEIGHT,
            
            // System constants
            'BROWSER_DEFAULT_FONT_SIZE' => self::BROWSER_DEFAULT_FONT_SIZE,
            'CSS_UNIT_CONVERSION_BASE' => self::CSS_UNIT_CONVERSION_BASE,
            
            // Validation ranges
            'MIN_ROOT_SIZE_RANGE' => self::MIN_ROOT_SIZE_RANGE,
            'VIEWPORT_RANGE' => self::VIEWPORT_RANGE,
            'LINE_HEIGHT_RANGE' => self::LINE_HEIGHT_RANGE,
            'SCALE_RANGE' => self::SCALE_RANGE,
            
            // Valid options
            'VALID_UNITS' => self::VALID_UNITS,
            'VALID_TABS' => self::VALID_TABS
        ];
    }

    /**
     * Get the property name for a size type
     * @param string $type Size type
     * @return string Property name
     */
    private function get_size_property_name($type)
    {
        $property_map = [
            'class' => 'className',
            'vars' => 'variableName',
            'tags' => 'tagName'
        ];

        return $property_map[$type] ?? 'className';
    }

    /**
     * Initialize WordPress hooks
     */
    private function init_hooks()
    {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('wp_ajax_save_font_clamp_sizes', [$this, 'save_sizes']);
        add_action('wp_ajax_save_font_clamp_settings', [$this, 'save_settings']);
    }

    /**
     * Add admin menu page
     */
    public function add_admin_menu()
    {
        add_menu_page(
            'Font Clamp Calculator',
            'Font Clamp',
            'manage_options',
            self::PLUGIN_SLUG,
            [$this, 'render_admin_page'],
            'dashicons-editor-textcolor',
            12
        );
    }

    /**
     * ENHANCED: Asset enqueuing with complete constants access
     */
    public function enqueue_assets()
    {
        $screen = get_current_screen();

        // Only enqueue on our plugin page
        if (!$screen || !isset($_GET['page']) || $_GET['page'] !== self::PLUGIN_SLUG) {
            return;
        }

        // Enqueue Tailwind CSS
        wp_enqueue_style(
            'font-clamp-tailwind',
            'https://cdn.tailwindcss.com',
            [],
            self::VERSION
        );

        // Enqueue WordPress utilities
        wp_enqueue_script('wp-util');

        // ENHANCED: Localize script with complete constants access
        wp_localize_script('wp-util', 'fontClampAjax', [
            'nonce' => wp_create_nonce(self::NONCE_ACTION),
            'ajaxurl' => admin_url('admin-ajax.php'),
            'defaults' => [
                'minRootSize' => self::DEFAULT_MIN_ROOT_SIZE,
                'maxRootSize' => self::DEFAULT_MAX_ROOT_SIZE,
                'minViewport' => self::DEFAULT_MIN_VIEWPORT,
                'maxViewport' => self::DEFAULT_MAX_VIEWPORT,
            ],
            // Complete data with actual font data
            'data' => [
                'settings' => $this->get_font_clamp_settings(),
                'classSizes' => $this->get_font_clamp_class_sizes(),
                'variableSizes' => $this->get_font_clamp_variable_sizes(),
                'tagSizes' => $this->get_font_clamp_tag_sizes()
            ],
            // NEW: Complete constants access for JavaScript
            'constants' => $this->get_all_constants(),
            'version' => self::VERSION,
            'debug' => defined('WP_DEBUG') && WP_DEBUG
        ]);
    }

    /**
     * Enhanced getter with caching and validation
     * @return array Settings with validation
     */
    public function get_font_clamp_settings()
    {
        static $cached_settings = null;

        if ($cached_settings === null) {
            $settings = get_option(self::OPTION_SETTINGS, $this->default_settings);

            // Validate activeTab on retrieval and fix if invalid
            if (!in_array($settings['activeTab'], self::VALID_TABS)) {
                $settings['activeTab'] = 'class';
                // Update the option to fix invalid data
                update_option(self::OPTION_SETTINGS, $settings);
            }

            $cached_settings = $settings;
        }

        return $cached_settings;
    }

    /**
     * Enhanced getters with static caching
     */
    public function get_font_clamp_class_sizes()
    {
        static $cached_sizes = null;
        if ($cached_sizes === null) {
            $cached_sizes = get_option(self::OPTION_CLASS_SIZES, $this->default_class_sizes);
        }
        return $cached_sizes;
    }

    public function get_font_clamp_variable_sizes()
    {
        static $cached_sizes = null;
        if ($cached_sizes === null) {
            $cached_sizes = get_option(self::OPTION_VARIABLE_SIZES, $this->default_variable_sizes);
        }
        return $cached_sizes;
    }

    public function get_font_clamp_tag_sizes()
    {
        static $cached_sizes = null;
        if ($cached_sizes === null) {
            $cached_sizes = get_option(self::OPTION_TAG_SIZES, $this->default_tag_sizes);
        }
        return $cached_sizes;
    }

    /**
     * Validate numeric value within range
     * @param mixed $value Value to validate
     * @param array $range [min, max] range
     * @param float $default Default value if invalid
     * @return float Validated value
     */
    private function validate_numeric_range($value, $range, $default)
    {
        $num = is_numeric($value) ? (float) $value : $default;
        return max($range[0], min($range[1], $num));
    }

    /**
     * Validate unit type
     * @param mixed $unit Unit to validate
     * @return string Valid unit
     */
    private function validate_unit_type($unit)
    {
        return in_array($unit, self::VALID_UNITS, true) ? $unit : 'px';
    }

    /**
     * Validate tab name
     * @param mixed $tab Tab to validate
     * @return string Valid tab
     */
    private function validate_tab_name($tab)
    {
        return in_array($tab, self::VALID_TABS, true) ? $tab : 'class';
    }

    /**
     * Validate scale value
     * @param mixed $scale Scale to validate
     * @param float $default Default value
     * @return float Valid scale
     */
    private function validate_scale($scale, $default)
    {
        $num = is_numeric($scale) ? (float) $scale : $default;
        return $this->validate_numeric_range($num, self::SCALE_RANGE, $default);
    }

    /**
     * Validate line height
     * @param mixed $lineHeight Line height to validate
     * @return float Valid line height
     */
    private function validate_line_height($lineHeight)
    {
        return $this->validate_numeric_range($lineHeight, self::LINE_HEIGHT_RANGE, self::DEFAULT_LINE_HEIGHT);
    }

    /**
     * Validate font URL (only HTTPS URLs and font file extensions)
     * @param string $url URL to validate
     * @return string Valid URL or empty string
     */
    private function validate_font_url($url)
    {
        if (empty($url)) {
            return '';
        }

        // Only allow HTTPS URLs and common font file extensions
        if (
            !filter_var($url, FILTER_VALIDATE_URL) ||
            !preg_match('/^https:\/\//', $url) ||
            !preg_match('/\.(woff2?|ttf|otf)(\?.*)?$/i', $url)
        ) {
            return '';
        }

        return esc_url_raw($url);
    }

    /**
     * Enhanced sizes array sanitization
     * @param string $json_string JSON string to sanitize
     * @return array|false Sanitized sizes or false on error
     */
    private function sanitize_sizes_array($json_string)
    {
        $data = json_decode(stripslashes($json_string), true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            error_log('Font Clamp: Invalid JSON in sizes: ' . json_last_error_msg());
            return false;
        }

        return array_map(function ($item) {
            if (!is_array($item)) {
                return null;
            }

            return [
                'id' => (int) ($item['id'] ?? 0),
                'className' => sanitize_html_class($item['className'] ?? ''),
                'variableName' => sanitize_text_field($item['variableName'] ?? ''),
                'tagName' => sanitize_text_field($item['tagName'] ?? ''),
                'min' => $this->validate_numeric_range($item['min'] ?? 0, [0, 200], 0),
                'max' => $this->validate_numeric_range($item['max'] ?? 0, [0, 200], 0),
                'lineHeight' => $this->validate_line_height($item['lineHeight'] ?? self::DEFAULT_LINE_HEIGHT)
            ];
        }, array_filter($data, 'is_array')); // Filter out non-array items
    }

    /**
     * Enhanced settings sanitization using validated methods
     * @param string $json_string JSON string to sanitize
     * @return array|false Sanitized settings or false on error
     */
    private function sanitize_settings_array($json_string)
    {
        $data = json_decode(stripslashes($json_string), true);

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            error_log('Font Clamp: Invalid JSON in settings: ' . json_last_error_msg());
            return false;
        }

        $settings = [
            'minRootSize' => $this->validate_numeric_range(
                $data['minRootSize'] ?? self::DEFAULT_MIN_ROOT_SIZE,
                self::MIN_ROOT_SIZE_RANGE,
                self::DEFAULT_MIN_ROOT_SIZE
            ),
            'maxRootSize' => $this->validate_numeric_range(
                $data['maxRootSize'] ?? self::DEFAULT_MAX_ROOT_SIZE,
                self::MIN_ROOT_SIZE_RANGE,
                self::DEFAULT_MAX_ROOT_SIZE
            ),
            'minViewport' => $this->validate_numeric_range(
                $data['minViewport'] ?? self::DEFAULT_MIN_VIEWPORT,
                self::VIEWPORT_RANGE,
                self::DEFAULT_MIN_VIEWPORT
            ),
            'maxViewport' => $this->validate_numeric_range(
                $data['maxViewport'] ?? self::DEFAULT_MAX_VIEWPORT,
                self::VIEWPORT_RANGE,
                self::DEFAULT_MAX_VIEWPORT
            ),
            'unitType' => $this->validate_unit_type($data['unitType'] ?? 'px'),
            'selectedClassSizeId' => (int) ($data['selectedClassSizeId'] ?? 5),
            'selectedVariableSizeId' => (int) ($data['selectedVariableSizeId'] ?? 5),
            'selectedTagSizeId' => (int) ($data['selectedTagSizeId'] ?? 1),
            'activeTab' => $this->validate_tab_name($data['activeTab'] ?? 'class'),
            'previewFontUrl' => $this->validate_font_url($data['previewFontUrl'] ?? ''),
            'minScale' => $this->validate_scale($data['minScale'] ?? self::DEFAULT_MIN_SCALE, self::DEFAULT_MIN_SCALE),
            'maxScale' => $this->validate_scale($data['maxScale'] ?? self::DEFAULT_MAX_SCALE, self::DEFAULT_MAX_SCALE),
            'autosaveEnabled' => (bool) ($data['autosaveEnabled'] ?? true),
            'classBaseValue' => sanitize_text_field($data['classBaseValue'] ?? 'medium'),
            'varsBaseValue' => sanitize_text_field($data['varsBaseValue'] ?? '--fs-md'),
            'tagBaseValue' => sanitize_text_field($data['tagBaseValue'] ?? 'p')
        ];

        // Cross-field validation
        if ($settings['minRootSize'] >= $settings['maxRootSize']) {
            $settings['maxRootSize'] = $settings['minRootSize'] + 4;
        }

        if ($settings['minViewport'] >= $settings['maxViewport']) {
            $settings['maxViewport'] = $settings['minViewport'] + 500;
        }

        return $settings;
    }

    /**
     * Verify AJAX request security
     * @return bool True if request is valid
     */
    private function verify_ajax_request()
    {
        // Check user capabilities
        if (!current_user_can('manage_options')) {
            wp_send_json_error([
                'message' => 'Insufficient permissions',
                'code' => 'INSUFFICIENT_PERMISSIONS'
            ]);
            return false;
        }

        // Check nonce
        if (!check_ajax_referer(self::NONCE_ACTION, 'nonce', false)) {
            wp_send_json_error([
                'message' => 'Security check failed',
                'code' => 'NONCE_VERIFICATION_FAILED'
            ]);
            return false;
        }

        return true;
    }

    /**
     * Validate sizes array completeness
     * @param array $sizes Sizes array to check
     * @param string $name_field Name field to check
     * @return bool True if valid
     */
    private function validate_sizes_completeness($sizes, $name_field)
    {
        foreach ($sizes as $size) {
            if (empty($size['id']) || empty($size[$name_field])) {
                return false;
            }
        }
        return true;
    }

    /**
     * Validate settings business logic
     * @param array $settings Settings to validate
     * @return array Array of validation errors
     */
    private function validate_settings_logic($settings)
    {
        $errors = [];

        // Check viewport ranges
        if ($settings['minViewport'] >= $settings['maxViewport']) {
            $errors[] = 'Minimum viewport must be less than maximum viewport';
        }

        // Check root size ranges
        if ($settings['minRootSize'] >= $settings['maxRootSize']) {
            $errors[] = 'Minimum root size must be less than maximum root size';
        }

        // Check scale ranges
        if ($settings['minScale'] >= $settings['maxScale']) {
            $errors[] = 'Minimum scale must be less than maximum scale';
        }

        return $errors;
    }

    /**
     * Enhanced save sizes with detailed validation
     */
    public function save_sizes()
    {
        // Security checks
        if (!$this->verify_ajax_request()) {
            return;
        }

        try {
            $class_sizes = $this->sanitize_sizes_array($_POST['class_sizes'] ?? '');
            $variable_sizes = $this->sanitize_sizes_array($_POST['variable_sizes'] ?? '');
            $tag_sizes = $this->sanitize_sizes_array($_POST['tag_sizes'] ?? '');

            // Validate all arrays
            if ($class_sizes === false) {
                wp_send_json_error([
                    'message' => 'Invalid class sizes data provided',
                    'code' => 'INVALID_CLASS_SIZES'
                ]);
                return;
            }

            if ($variable_sizes === false) {
                wp_send_json_error([
                    'message' => 'Invalid variable sizes data provided',
                    'code' => 'INVALID_VARIABLE_SIZES'
                ]);
                return;
            }

            if ($tag_sizes === false) {
                wp_send_json_error([
                    'message' => 'Invalid tag sizes data provided',
                    'code' => 'INVALID_TAG_SIZES'
                ]);
                return;
            }

            // Additional validation - check for required fields
            if (
                !$this->validate_sizes_completeness($class_sizes, 'className') ||
                !$this->validate_sizes_completeness($variable_sizes, 'variableName') ||
                !$this->validate_sizes_completeness($tag_sizes, 'tagName')
            ) {
                wp_send_json_error([
                    'message' => 'Missing required size data',
                    'code' => 'INCOMPLETE_SIZE_DATA'
                ]);
                return;
            }

            // Save to database
            update_option(self::OPTION_CLASS_SIZES, $class_sizes);
            update_option(self::OPTION_VARIABLE_SIZES, $variable_sizes);
            update_option(self::OPTION_TAG_SIZES, $tag_sizes);

            wp_send_json_success([
                'message' => 'All sizes saved successfully',
                'counts' => [
                    'class_sizes' => count($class_sizes),
                    'variable_sizes' => count($variable_sizes),
                    'tag_sizes' => count($tag_sizes)
                ]
            ]);
        } catch (Exception $e) {
            error_log('Font Clamp save_sizes error: ' . $e->getMessage());
            wp_send_json_error([
                'message' => 'An unexpected error occurred while saving sizes',
                'code' => 'UNEXPECTED_ERROR'
            ]);
        }
    }

    /**
     * Enhanced save settings with cross-validation
     */
    public function save_settings()
    {
        if (!$this->verify_ajax_request()) {
            return;
        }

        try {
            $settings = $this->sanitize_settings_array($_POST['settings'] ?? '');

            if ($settings === false) {
                wp_send_json_error([
                    'message' => 'Invalid settings data provided',
                    'code' => 'INVALID_SETTINGS_DATA'
                ]);
                return;
            }

            // Additional business logic validation
            $validation_errors = $this->validate_settings_logic($settings);
            if (!empty($validation_errors)) {
                wp_send_json_error([
                    'message' => 'Settings validation failed',
                    'code' => 'VALIDATION_FAILED',
                    'errors' => $validation_errors
                ]);
                return;
            }

            update_option(self::OPTION_SETTINGS, $settings);

            wp_send_json_success([
                'message' => 'Settings saved successfully',
                'settings' => $settings
            ]);
        } catch (Exception $e) {
            error_log('Font Clamp save_settings error: ' . $e->getMessage());
            wp_send_json_error([
                'message' => 'An unexpected error occurred while saving settings',
                'code' => 'UNEXPECTED_ERROR'
            ]);
        }
    }

    /**
     * Main Admin Page Renderer with Filter Support
     */
    public function render_admin_page()
    {
        // Get data for any segment that needs it
        $data = [
            'settings' => $this->get_font_clamp_settings(),
            'class_sizes' => $this->get_font_clamp_class_sizes(),
            'variable_sizes' => $this->get_font_clamp_variable_sizes(),
            'tag_sizes' => $this->get_font_clamp_tag_sizes()
        ];

        // Apply filter to allow segments to override the output
        $content = apply_filters('font_clamp_render_content', $this->get_default_content(), $data);

        echo $content;
    }

    /**
     * Default content when Segment B is not loaded
     */
    private function get_default_content()
    {
        return '<div class="wrap">
            <h1>Font Clamp Calculator (' . self::VERSION . ') - Foundation Only</h1>
            <div style="background: #fff3cd; padding: 20px; border-radius: 8px; margin: 20px 0; border: 1px solid #ffeaa7;">
                <h2>🔧 Interface Segment Not Loaded</h2>
                <p><strong>Segment A (Foundation):</strong> ✅ WordPress hooks, data management, AJAX handlers loaded</p>
                <p><strong>Segment B (Interface):</strong> ❌ Not loaded or not working</p>
                <hr style="margin: 15px 0;">
                <p><strong>Status:</strong></p>
                <ul>
                    <li>✅ Class instantiated successfully</li>
                    <li>✅ WordPress hooks registered</li>
                    <li>✅ Default data initialized</li>
                    <li>✅ AJAX endpoints ready</li>
                    <li>✅ Enhanced validation active</li>
                    <li>✅ Conflict-resistant method naming</li>
                    <li>✅ Complete constants system with no magic numbers</li>
                    <li>❌ No UI segment found</li>
                </ul>
                <p><em>Load Segment B to see the complete interface.</em></p>
            </div>
        </div>';
    }
}

// Store the instance globally so other segments can access it
global $fontClampCalculator;
$fontClampCalculator = new FontClampCalculator();
?>