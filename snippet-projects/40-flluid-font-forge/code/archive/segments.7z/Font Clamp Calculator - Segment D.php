<?php
/**
 * Font Clamp Calculator - Segment D 
 * Version: 3.5 Copy Functionality
 *
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Copy Functionality Controller Class
 * 
 * Handles copy buttons with proper JimRWeb branding and positioning
 */
class FontClampCopyFunctionality {
    
    /**
     * Version for cache busting
     */
    private $version = '3.5.0';

    /**
     * Constructor
     */
    public function __construct() {
        $this->init();
    }

    /**
     * Initialize the copy functionality
     */
    private function init() {
        // Only load on plugin page
        if (!$this->is_plugin_page()) {
            return;
        }

        // Add CSS for proper copy button styling
        add_action('admin_footer', [$this, 'render_copy_button_styles'], 25);
        
        // Add JavaScript for copy functionality
        add_action('admin_footer', [$this, 'render_javascript'], 30);
    }

    /**
     * Check if we're on the plugin page
     */
    private function is_plugin_page() {
        return isset($_GET['page']) && sanitize_text_field($_GET['page']) === 'font-clamp-calculator';
    }

    /**
     * Render copy button specific styles
     */
    public function render_copy_button_styles() {
        ?>
        <style id="font-clamp-copy-styles">
            /* Copy Button Specific Styles - JimRWeb Branded */
            .fcc-css-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: var(--jimr-space-4);
            }

            .fcc-css-header h2 {
                margin: 0 !important;
                border: none !important;
                padding: 0 !important;
            }

            .fcc-copy-btn {
                background: var(--jimr-accent);
                color: var(--jimr-btn-text);
                border: 2px solid var(--jimr-btn-border);
                padding: var(--jimr-space-2) var(--jimr-space-4);
                border-radius: var(--jimr-border-radius);
                font-size: var(--jimr-font-sm);
                font-weight: 600;
                font-style: italic;
                text-transform: lowercase;
                letter-spacing: 0.5px;
                transition: var(--jimr-transition-slow);
                cursor: pointer;
                box-shadow: var(--jimr-shadow);
                position: relative;
                overflow: hidden;
                display: inline-flex;
                align-items: center;
                gap: var(--jimr-space-2);
                text-decoration: none;
                border: none;
                min-width: 80px;
                justify-content: center;
            }

            .fcc-copy-btn::before {
                content: '';
                position: absolute;
                top: 50%;
                left: 50%;
                width: 0;
                height: 0;
                background: rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                transform: translate(-50%, -50%);
                transition: width 0.6s, height 0.6s;
            }

            .fcc-copy-btn:active::before {
                width: 300px;
                height: 300px;
            }

            .fcc-copy-btn:hover {
                background: var(--jimr-btn-hover);
                transform: translateY(-2px);
                box-shadow: var(--jimr-shadow-lg);
            }

            .fcc-copy-btn:active {
                transform: translateY(0) scale(0.98);
                box-shadow: var(--jimr-shadow);
            }

            .fcc-copy-btn:focus {
                outline: none;
                box-shadow: 0 0 0 3px rgba(255, 215, 0, 0.3), var(--jimr-shadow-lg);
            }

            .fcc-copy-btn.success {
                background: var(--jimr-success);
                border-color: var(--jimr-success-dark);
                color: white;
                font-style: normal;
                text-transform: none;
                letter-spacing: normal;
            }

            .copy-icon {
                font-size: var(--jimr-font-sm);
            }

            /* Copy feedback notification */
            .fcc-copy-notification {
                position: fixed;
                top: 20px;
                right: 20px;
                background: linear-gradient(135deg, var(--jimr-success), var(--jimr-success-dark));
                color: white;
                padding: 12px 16px;
                border-radius: var(--jimr-border-radius-lg);
                font-size: var(--jimr-font-sm);
                font-weight: 500;
                box-shadow: var(--jimr-shadow-xl);
                z-index: 10003;
                max-width: 300px;
                opacity: 0;
                transform: translateX(100%);
                transition: all 0.3s ease;
                border: 1px solid rgba(255, 255, 255, 0.1);
            }

            .fcc-copy-notification.show {
                opacity: 1;
                transform: translateX(0);
            }

            /* Button group for multiple copy buttons */
            .fcc-css-buttons {
                display: flex;
                gap: var(--jimr-space-2);
                align-items: center;
            }
        </style>
        <?php
    }

    /**
     * Render copy functionality JavaScript with proper JimRWeb branding
     */
    public function render_javascript() {
        ?>
        <script id="font-clamp-copy-script">
            console.log('📋 Font Clamp Copy Functionality v3.5 - JimRWeb Branded Edition loading...');

            /**
             * Copy Functionality Controller with JimRWeb Branding
             */
            class FontClampCopyController {
                constructor() {
                    this.version = '3.5.0';
                    this.initialized = false;
                    this.copyCount = 0;
                    this.lastCopyTime = 0;

                    this.init();
                }

                /**
                 * Initialize the copy functionality
                 */
                init() {
                    console.log('🚀 Initializing JimRWeb Branded Copy Functionality...');

                    // Wait for other segments to be ready
                    this.waitForSegments();
                }

                /**
                 * Wait for core segment and initialize copy buttons
                 */
                waitForSegments() {
                    // Listen for core ready event
                    window.addEventListener('fontClampCoreReady', () => {
                        this.initializeCopyButtons();
                    });

                    // Fallback initialization after timeout
                    setTimeout(() => {
                        if (!this.initialized) {
                            console.log('⚠️ Core not fully ready, initializing copy buttons anyway');
                            this.initializeCopyButtons();
                        }
                    }, 2000);
                }

                /**
                 * Initialize copy buttons with JimRWeb branding and proper positioning
                 */
                initializeCopyButtons() {
                    try {
                        this.addCopyButtonToSelectedCSS();
                        this.addCopyButtonToGeneratedCSS();
                        this.setupKeyboardShortcuts();

                        this.initialized = true;
                        console.log('✅ JimRWeb branded copy functionality initialized successfully');

                        // Trigger event to let other segments know copy is ready
                        window.dispatchEvent(new CustomEvent('fontClampCopyReady', {
                            detail: {
                                copyController: this
                            }
                        }));

                    } catch (error) {
                        console.error('❌ Failed to initialize copy functionality:', error);
                    }
                }

                /**
                 * Add properly positioned and branded copy button to Selected CSS panel
                 */
                addCopyButtonToSelectedCSS() {
                    const container = document.getElementById('selected-copy-button');
                    if (!container) return;

                    const activeTab = window.fontClampCore?.activeTab || 'class';
                    const tooltipText = this.getSelectedCSSTooltip(activeTab);

                    container.innerHTML = `
                        <button id="copy-selected-btn" class="fcc-copy-btn" 
                                data-tooltip="${tooltipText}" 
                                data-tooltip-type="info"
                                aria-label="Copy selected CSS to clipboard"
                                title="Copy CSS">
                            <span class="copy-icon">📋</span> copy
                        </button>
                    `;

                    document.getElementById('copy-selected-btn').addEventListener('click', () => {
                        this.copySelectedCSS();
                    });

                    // Update tooltip when tab changes
                    window.addEventListener('fontClamp_tabChanged', (e) => {
                        const button = document.getElementById('copy-selected-btn');
                        if (button) {
                            button.setAttribute('data-tooltip', this.getSelectedCSSTooltip(e.detail.activeTab));
                        }
                    });
                }

                /**
                 * Add properly positioned and branded copy button to Generated CSS panel
                 */
                addCopyButtonToGeneratedCSS() {
                    const container = document.getElementById('generated-copy-buttons');
                    if (!container) return;

                    const activeTab = window.fontClampCore?.activeTab || 'class';
                    const tooltipText = this.getGeneratedCSSTooltip(activeTab);

                    container.innerHTML = `
                        <button id="copy-all-btn" class="fcc-copy-btn" 
                                data-tooltip="${tooltipText}" 
                                data-tooltip-type="success"
                                aria-label="Copy all generated CSS to clipboard"
                                title="Copy All CSS">
                            <span class="copy-icon">📋</span> copy all
                        </button>
                    `;

                    document.getElementById('copy-all-btn').addEventListener('click', () => {
                        this.copyGeneratedCSS();
                    });

                    // Update tooltip when tab changes
                    window.addEventListener('fontClamp_tabChanged', (e) => {
                        const button = document.getElementById('copy-all-btn');
                        if (button) {
                            button.setAttribute('data-tooltip', this.getGeneratedCSSTooltip(e.detail.activeTab));
                        }
                    });
                }

                /**
                 * Get tooltip text for selected CSS based on active tab
                 */
                getSelectedCSSTooltip(activeTab) {
                    switch (activeTab) {
                        case 'class':
                            return 'Copy the CSS for your selected class. Paste this into your stylesheet to use the responsive font size for this specific class.';
                        case 'vars':
                            return 'Copy the CSS custom property for your selected variable. Add this to your :root selector and reference it with var() in your CSS.';
                        case 'tag':
                            return 'Copy the CSS for your selected HTML tag. This will automatically apply responsive font sizing to all instances of this tag.';
                        default:
                            return 'Copy the selected CSS to your clipboard for use in your project.';
                    }
                }

                /**
                 * Get tooltip text for generated CSS based on active tab
                 */
                getGeneratedCSSTooltip(activeTab) {
                    switch (activeTab) {
                        case 'class':
                            return 'Copy all CSS classes with responsive font sizes. This gives you a complete font system that works across all screen sizes. Perfect for utility-first CSS approaches.';
                        case 'vars':
                            return 'Copy all CSS custom properties. Add this to your :root selector to create a complete variable-based font system that you can reference throughout your CSS.';
                        case 'tag':
                            return 'Copy all HTML tag styles. This creates automatic responsive typography for your entire document without needing to add classes to your HTML.';
                        default:
                            return 'Copy all generated CSS to create a complete responsive font system for your project.';
                    }
                }

                /**
                 * Setup keyboard shortcuts for copy operations
                 */
                setupKeyboardShortcuts() {
                    document.addEventListener('keydown', (e) => {
                        // Ctrl/Cmd + Shift + C for selected CSS
                        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'C') {
                            e.preventDefault();
                            this.copySelectedCSS();
                            this.showNotification('⌨️ Copied selected CSS via keyboard shortcut');
                        }
                        
                        // Ctrl/Cmd + Shift + A for all CSS
                        if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'A') {
                            e.preventDefault();
                            this.copyGeneratedCSS();
                            this.showNotification('⌨️ Copied all CSS via keyboard shortcut');
                        }
                    });
                }

                /**
                 * Copy selected CSS to clipboard with enhanced feedback
                 */
                copySelectedCSS() {
                    const cssElement = document.getElementById('class-code');
                    if (!cssElement) {
                        this.showNotification('❌ No CSS element found', 'error');
                        return;
                    }

                    const cssText = cssElement.textContent || cssElement.innerText;
                    
                    if (!cssText || cssText.includes('Loading CSS') || cssText.includes('No CSS')) {
                        this.showNotification('⚠️ No CSS available to copy - try selecting a font size first', 'warning');
                        return;
                    }

                    const button = document.getElementById('copy-selected-btn');
                    this.copyToClipboard(cssText, button, 'Selected CSS copied!');
                    
                    // Track copy analytics
                    this.trackCopyAction('selected', cssText.length);
                }

                /**
                 * Copy generated CSS to clipboard with enhanced feedback
                 */
                copyGeneratedCSS() {
                    const cssElement = document.getElementById('generated-code');
                    if (!cssElement) {
                        this.showNotification('❌ No CSS element found', 'error');
                        return;
                    }

                    const cssText = cssElement.textContent || cssElement.innerText;
                    
                    if (!cssText || cssText.includes('Loading CSS') || cssText.includes('No CSS')) {
                        this.showNotification('⚠️ No CSS available to copy - try adding some font sizes first', 'warning');
                        return;
                    }

                    const button = document.getElementById('copy-all-btn');
                    this.copyToClipboard(cssText, button, 'Complete CSS copied!');
                    
                    // Track copy analytics
                    this.trackCopyAction('all', cssText.length);
                }

                /**
                 * Copy text to clipboard with enhanced visual feedback
                 */
                copyToClipboard(text, button, message) {
                    const startTime = performance.now();

                    if (navigator.clipboard && navigator.clipboard.writeText) {
                        navigator.clipboard.writeText(text).then(() => {
                            this.showButtonSuccess(button);
                            this.showNotification(message);
                        }).catch(err => {
                            console.error('Copy failed:', err);
                            this.fallbackCopy(text);
                            this.showButtonSuccess(button);
                            this.showNotification(message + ' (Legacy Method)');
                        });
                    } else {
                        this.fallbackCopy(text);
                        this.showButtonSuccess(button);
                        this.showNotification(message + ' (Legacy Method)');
                    }
                }

                /**
                 * Fallback copy method for older browsers
                 */
                fallbackCopy(text) {
                    const textarea = document.createElement('textarea');
                    textarea.value = text;
                    textarea.style.position = 'fixed';
                    textarea.style.opacity = '0';
                    textarea.style.top = '-9999px';
                    textarea.style.left = '-9999px';
                    document.body.appendChild(textarea);
                    textarea.select();
                    textarea.setSelectionRange(0, 99999); // For mobile devices
                    
                    try {
                        document.execCommand('copy');
                    } catch (err) {
                        console.error('Fallback copy failed:', err);
                    }
                    
                    document.body.removeChild(textarea);
                }

                /**
                 * Show button success state with JimRWeb branding
                 */
                showButtonSuccess(button) {
                    if (!button) return;

                    button.classList.add('success');
                    
                    // Add haptic feedback if available
                    if (navigator.vibrate) {
                        navigator.vibrate([50, 25, 50]);
                    }

                    setTimeout(() => {
                        button.classList.remove('success');
                    }, 1500);
                }

                /**
                 * Track copy actions for analytics
                 */
                trackCopyAction(type, cssLength) {
                    this.copyCount++;
                    this.lastCopyTime = Date.now();

                    // Log for debugging (could be sent to analytics service)
                    console.log(`📊 Copy Action: ${type}, Length: ${cssLength}, Total Copies: ${this.copyCount}`);

                    // Store in localStorage for session persistence
                    try {
                        const stats = JSON.parse(localStorage.getItem('fontClampCopyStats') || '{}');
                        stats.totalCopies = (stats.totalCopies || 0) + 1;
                        stats.lastCopy = this.lastCopyTime;
                        stats[`${type}Copies`] = (stats[`${type}Copies`] || 0) + 1;
                        localStorage.setItem('fontClampCopyStats', JSON.stringify(stats));
                    } catch (e) {
                        // localStorage not available, continue silently
                    }
                }

                /**
                 * Show notification with JimRWeb styling
                 */
                showNotification(message, type = 'success', duration = 3000) {
                    // Create or update notification element
                    let notification = document.getElementById('fcc-copy-notification');
                    
                    if (!notification) {
                        notification = document.createElement('div');
                        notification.id = 'fcc-copy-notification';
                        notification.className = 'fcc-copy-notification';
                        document.body.appendChild(notification);
                    }

                    // Update style based on type
                    const typeStyles = {
                        'success': 'background: linear-gradient(135deg, var(--jimr-success), var(--jimr-success-dark));',
                        'warning': 'background: linear-gradient(135deg, var(--jimr-warning), var(--jimr-warning-dark));',
                        'error': 'background: linear-gradient(135deg, var(--jimr-danger), var(--jimr-danger-dark));'
                    };

                    if (typeStyles[type]) {
                        notification.style.cssText += typeStyles[type];
                    }

                    notification.textContent = message;
                    notification.classList.add('show');

                    // Hide notification
                    setTimeout(() => {
                        notification.classList.remove('show');
                    }, duration);

                    console.log('📢 Notification:', message);
                }

                /**
                 * Get copy statistics for debugging
                 */
                getCopyStats() {
                    try {
                        return JSON.parse(localStorage.getItem('fontClampCopyStats') || '{}');
                    } catch (e) {
                        return {};
                    }
                }

                /**
                 * Reset copy statistics
                 */
                resetCopyStats() {
                    try {
                        localStorage.removeItem('fontClampCopyStats');
                        this.copyCount = 0;
                        this.lastCopyTime = 0;
                        console.log('📊 Copy statistics reset');
                    } catch (e) {
                        // localStorage not available, continue silently
                    }
                }
            }

            // Initialize the copy controller
            window.fontClampCopy = new FontClampCopyController();

            console.log('✅ Font Clamp Copy Functionality v3.5 - JimRWeb Branded Edition loaded successfully!');
        </script>
        <?php
    }
}

// Initialize only if Segment A loaded successfully
if (class_exists('FontClampCalculator')) {
    new FontClampCopyFunctionality();
} else {
    // Add admin notice if Segment A not found
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p><strong>Font Clamp Calculator Copy Functionality:</strong> Cannot load - Segment A (Foundation) not found. Please load Segment A first.</p></div>';
    });
}
?>