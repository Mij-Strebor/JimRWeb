<?php

/**
 * Font Clamp Calculator - Segment B
 * Version: 3.5 - Enhanced Core Interface Layer - MAGIC NUMBER FIX
 * 
 * All magic numbers replaced with proper constants from Segment A
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Only proceed if Segment A loaded successfully
if (class_exists('FontClampCalculator')) {

    // Hook into the render filter to provide our enhanced core interface
    add_filter('font_clamp_render_content', 'font_clamp_render_enhanced_core_interface', 10, 2);

    /**
     * Enhanced core interface renderer - provides improved UI structure
     */
    function font_clamp_render_enhanced_core_interface($default_content, $data)
    {
        // Extract data from Segment A
        $settings = $data['settings'];
        $class_sizes = $data['class_sizes'];
        $variable_sizes = $data['variable_sizes'];
        $tag_sizes = $data['tag_sizes'];

        // Start output buffering to capture our HTML
        ob_start();
?>
        <div class="wrap" style="background: var(--jimr-page-bg); padding: 20px; min-height: 100vh;">
            <h1 class="text-2xl font-bold mb-4">Font Clamp Calculator (3.5)</h1>

            <!-- About Section - Collapsible Like How To Use -->
            <div class="fcc-info-toggle-section">
                <button class="fcc-info-toggle expanded" data-toggle-target="about-content">
                    <span style="color: #FAF9F6 !important;">ℹ️ About Font Clamp Calculator</span>
                    <span class="fcc-toggle-icon" style="color: #FAF9F6 !important;">▼</span>
                </button>
                <div class="fcc-info-content expanded" id="about-content">
                    <div style="color: #FAF9F6; font-size: 14px; line-height: 1.6;">
                        <p style="margin: 0 0 16px 0; color: #FAF9F6;">
                            I've been a font nerd for a while. I enjoy seeing designers presenting an attraction in a striking way that doesn't attract attention itself. It's exactly like a director, or cinematographer moves you into the emotional depth of a movie without you knowing it. When CSS clamp() came along, there was an explosion of responsive font management. That gave the font the ability to stop drawing attention to itself and present the message effectively. I recently visited a YouTube presentation by a favorite WordPress guru. There was a sophisticated calculator for font clamping demo development. This was better than many of the websites out there. But it wasn't enough! Here's my attempt. Enjoy.</p>
                        <div style="background: rgba(60, 32, 23, 0.1); padding: 12px 16px; border-radius: 6px; border-left: 4px solid var(--jimr-accent); margin-top: 20px;">
                            <p style="margin: 0; font-size: 13px; opacity: 0.95; line-height: 1.5; color: #FAF9F6;">Font Clamp Calculator by Jim R. (<a href="https://jimrweb.com" target="_blank" style="color: #CD5C5C; text-decoration: underline; font-weight: 600;">JimRWeb</a>), developed with tremendous help from Claude AI (<a href="https://anthropic.com" target="_blank" style="color: #CD5C5C; text-decoration: underline; font-weight: 600;">Anthropic</a>), based on an original snippet by Imran Siddiq (<a href="https://websquadron.co.uk" target="_blank" style="color: #CD5C5C; text-decoration: underline; font-weight: 600;">WebSquadron</a>), in his Font Clamp Calculator (2.2).</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- FLASH FIX: Loading State -->
            <div id="fcc-loading-screen" class="fcc-loading-screen">
                <div class="fcc-loading-content">
                    <div class="fcc-loading-spinner"></div>
                    <h2>Font Clamp Calculator<br><br>Loading...</h2>
                    <p>Initializing enhanced interface and advanced features...</p>
                    <div class="fcc-loading-progress">
                        <div class="fcc-progress-bar"></div>
                    </div>
                </div>
            </div>

            <div class="font-clamp-container" id="fcc-main-container">
                <div style="padding: 20px;">

                    <!-- ENHANCED: Collapsible Info Section - Starts Open -->
                    <div class="fcc-info-toggle-section">
                        <button class="fcc-info-toggle expanded" data-toggle-target="info-content">
                            <span style="color: #FAF9F6 !important;">ℹ️ How to Use Font Clamp Calculator</span>
                            <span class="fcc-toggle-icon" style="color: #FAF9F6 !important;">▼</span>
                        </button>
                        <div class="fcc-info-content expanded" id="info-content" style="color: #FAF9F6;">
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 16px;">
                                <div style="background: rgba(255, 255, 255, 0.1); padding: 16px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.2);">
                                    <h4 style="color: var(--jimr-secondary); font-size: 15px; font-weight: 600; margin: 0 0 8px 0;">1. Configure Settings</h4>
                                    <p style="margin: 0; font-size: 14px; line-height: 1.5; color: #FAF9F6;">Set your font units, viewport range, and scaling ratios. Choose a base value that represents your base root size font size.</p>
                                </div>

                                <div style="background: rgba(255, 255, 255, 0.1); padding: 16px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.2);">
                                    <h4 style="color: var(--jimr-secondary); font-size: 15px; font-weight: 600; margin: 0 0 8px 0;">2. Manage Font Sizes</h4>
                                    <p style="margin: 0; font-size: 14px; line-height: 1.5; color: #FAF9F6;">Use the enhanced table to add, edit, delete, or reorder your font sizes. Drag rows to reorder them in the table.</p>
                                </div>

                                <div style="background: rgba(255, 255, 255, 0.1); padding: 16px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.2);">
                                    <h4 style="color: var(--jimr-secondary); font-size: 15px; font-weight: 600; margin: 0 0 8px 0;">3. Preview Results</h4>
                                    <p style="margin: 0; font-size: 14px; line-height: 1.5; color: #FAF9F6;">Use the enhanced preview with controls to see how your fonts will look at different screen sizes. The displays are at scale at the ends of your entered Min Width and Max Width.</p>
                                </div>

                                <div style="background: rgba(255, 255, 255, 0.1); padding: 16px; border-radius: 8px; border: 1px solid rgba(255, 255, 255, 0.2);">
                                    <h4 style="color: var(--jimr-secondary); font-size: 15px; font-weight: 600; margin: 0 0 8px 0;">4. Copy CSS</h4>
                                    <p style="margin: 0; font-size: 14px; line-height: 1.5; color: #FAF9F6;">Generate clamp() CSS functions ready to use in your projects. Available as classes, variables, or tag styles with enhanced copy functionality.</p>
                                </div>
                            </div>

                            <div style="background: #F0E6DA; padding: 12px 16px; border-radius: 8px; border: 1px solid #5C3324; margin: 16px 0 20px 0; text-align: center;">
                                <h4 style="color: #3C2017; font-size: 14px; font-weight: 600; margin: 0 0 6px 0;">💡 Pro Tip</h4>
                                <p style="margin: 0; font-size: 13px; color: #FAF9F6;">Use Preview Font to test with your actual web fonts and enjoy the enhanced interactive experience with smooth animations and professional styling.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Enhanced Header Section -->
                    <div style="margin-bottom: 16px;">
                        <!-- Top Row: Preview Font Input and Autosave Status -->
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                            <div class="fcc-font-input">
                                <label for="preview-font-url" data-tooltip="Load a custom WOFF2 font file to preview your font sizes">Preview Font:</label>
                                <input type="text" id="preview-font-url" class="fcc-input" placeholder="Paste WOFF2 font URL" value="<?php echo esc_attr($settings['previewFontUrl']); ?>" style="width: 200px; margin-bottom: 0;" data-tooltip="Enter a WOFF2 font URL to see how your sizes look with that font">
                                <span id="font-filename">Default</span>
                            </div>

                            <div style="display: flex; align-items: center; gap: 20px;">
                                <div class="fcc-autosave-flex">
                                    <div id="autosave-status" class="autosave-status idle">
                                        <span id="autosave-icon">⚡</span>
                                        <span id="autosave-text">Loading...</span>
                                    </div>
                                    <label data-tooltip="Automatically save changes as you make them">
                                        <input type="checkbox" id="autosave-toggle" <?php echo $settings['autosaveEnabled'] ? 'checked' : ''; ?> data-tooltip="Toggle automatic saving of your font settings">
                                        <span>Autosave</span>
                                    </label>
                                </div>
                            </div>
                        </div>

                        <!-- Bottom Row: Large Tabs -->
                        <div style="display: flex; justify-content: center;">
                            <div class="fcc-tabs" style="width: 100%; max-width: 600px;">
                                <button id="class-tab" class="tab-button <?php echo $settings['activeTab'] === 'class' ? 'active' : ''; ?>" style="flex: 1; padding: 12px 24px; border-radius: 6px; font-size: 16px; font-weight: 600;" data-tab="class" data-tooltip="Generate CSS classes like .large, .medium, .small for use in HTML">Class</button>
                                <button id="vars-tab" class="tab-button <?php echo $settings['activeTab'] === 'vars' ? 'active' : ''; ?>" style="flex: 1; padding: 12px 24px; border-radius: 6px; font-size: 16px; font-weight: 600;" data-tab="vars" data-tooltip="Generate CSS custom properties like --fs-lg for use with var() in CSS">Variables</button>
                                <button id="tag-tab" class="tab-button <?php echo $settings['activeTab'] === 'tag' ? 'active' : ''; ?>" style="flex: 1; padding: 12px 24px; border-radius: 6px; font-size: 16px; font-weight: 600;" data-tab="tag" data-tooltip="Generate CSS that directly styles HTML tags like h1, h2, p automatically">Tags</button>
                            </div>
                        </div>
                    </div>

                    <!-- ENHANCED: Settings and Data Table - Side by Side -->
                    <div class="fcc-main-grid">
                        <!-- Column 1: CLEAN Settings Panel -->
                        <div>
                            <div class="fcc-panel" style="margin-bottom: 8px;">
                                <h2 class="settings-title">Settings</h2>
                                
                                <!-- Font Units Selector -->
                                <div class="font-units-section">
                                    <label class="font-units-label">Font Units</label>
                                    <div class="font-units-buttons">
                                        <button id="px-tab" class="unit-button <?php echo $settings['unitType'] === 'px' ? 'active' : ''; ?>" data-unit="px" data-tooltip="Use pixel units for font sizes - more predictable but less accessible">PX</button>
                                        <button id="rem-tab" class="unit-button <?php echo $settings['unitType'] === 'rem' ? 'active' : ''; ?>" data-unit="rem" data-tooltip="Use rem units for font sizes - scales with user's browser settings">REM</button>
                                    </div>
                                </div>

                                <!-- Row 1: Min Root, Min Width, Max Width -->
                                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; margin-top: 16px;">
                                    <div class="grid-item">
                                        <label class="component-label" for="min-root-size">Min Root (px)</label>
                                        <input type="number" id="min-root-size" value="<?php echo esc_attr($settings['minRootSize']); ?>" 
                                               class="component-input" style="width: 100%;" 
                                               min="<?php echo FontClampCalculator::MIN_ROOT_SIZE_RANGE[0]; ?>" 
                                               max="<?php echo FontClampCalculator::MIN_ROOT_SIZE_RANGE[1]; ?>" 
                                               step="1"
                                               data-tooltip="Base font size at minimum viewport width">
                                    </div>
                                    <div class="grid-item">
                                        <label class="component-label" for="min-viewport">Min Width (px)</label>
                                        <input type="number" id="min-viewport" value="<?php echo esc_attr($settings['minViewport']); ?>" 
                                               class="component-input" style="width: 100%;" 
                                               min="<?php echo FontClampCalculator::VIEWPORT_RANGE[0]; ?>" 
                                               max="<?php echo FontClampCalculator::VIEWPORT_RANGE[1]; ?>" 
                                               step="1"
                                               data-tooltip="Screen width where minimum font size applies">
                                    </div>
                                    <div class="grid-item">
                                        <label class="component-label" for="max-viewport">Max Width (px)</label>
                                        <input type="number" id="max-viewport" value="<?php echo esc_attr($settings['maxViewport']); ?>" 
                                               class="component-input" style="width: 100%;" 
                                               min="<?php echo FontClampCalculator::VIEWPORT_RANGE[0]; ?>" 
                                               max="<?php echo FontClampCalculator::VIEWPORT_RANGE[1]; ?>" 
                                               step="1"
                                               data-tooltip="Screen width where maximum font size applies">
                                    </div>
                                </div>

                                <!-- Row 2: Max Root, Min Scale -->
                                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; margin-top: 16px;">
                                    <div class="grid-item">
                                        <label class="component-label" for="max-root-size">Max Root (px)</label>
                                        <input type="number" id="max-root-size" value="<?php echo esc_attr($settings['maxRootSize']); ?>" 
                                               class="component-input" style="width: 100%;" 
                                               min="<?php echo FontClampCalculator::MIN_ROOT_SIZE_RANGE[0]; ?>" 
                                               max="<?php echo FontClampCalculator::MIN_ROOT_SIZE_RANGE[1]; ?>" 
                                               step="1"
                                               data-tooltip="Base font size at maximum viewport width">
                                    </div>
                                    <div class="grid-item" style="grid-column: 2 / 4;">
                                        <label class="component-label" for="min-scale">Min Scale</label>
                                        <select id="min-scale" class="component-select" style="width: 100%;" 
                                                data-tooltip="Typography scale ratio for smaller screens - how much size difference between font levels">
                                            <option value="1.067" <?php selected($settings['minScale'], '1.067'); ?>>1.067 Minor Second</option>
                                            <option value="1.125" <?php selected($settings['minScale'], '1.125'); ?>>1.125 Major Second</option>
                                            <option value="1.200" <?php selected($settings['minScale'], '1.200'); ?>>1.200 Minor Third</option>
                                            <option value="1.250" <?php selected($settings['minScale'], '1.250'); ?>>1.250 Major Third</option>
                                            <option value="1.333" <?php selected($settings['minScale'], '1.333'); ?>>1.333 Perfect Fourth</option>
                                            <option value="1.414" <?php selected($settings['minScale'], '1.414'); ?>>1.414 Augmented Fourth</option>
                                            <option value="1.500" <?php selected($settings['minScale'], '1.500'); ?>>1.500 Perfect Fifth</option>
                                            <option value="1.618" <?php selected($settings['minScale'], '1.618'); ?>>1.618 Golden Ratio</option>
                                            <option value="1.667" <?php selected($settings['minScale'], '1.667'); ?>>1.667 Major Sixth</option>
                                            <option value="1.778" <?php selected($settings['minScale'], '1.778'); ?>>1.778 Minor Seventh</option>
                                            <option value="1.875" <?php selected($settings['minScale'], '1.875'); ?>>1.875 Major Seventh</option>
                                            <option value="2.000" <?php selected($settings['minScale'], '2.000'); ?>>2.000 Octave</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Row 3: Base Value, Max Scale -->
                                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 16px; margin-top: 16px;">
                                    <div class="grid-item">
                                        <label class="component-label" for="base-value">Base Value</label>
                                        <select id="base-value" class="component-input" style="width: 100%;" 
                                                data-tooltip="Reference size used for calculating other sizes - this will be your body text size">
                                            <!-- Segment C will populate this -->
                                        </select>
                                    </div>
                                    <div class="grid-item" style="grid-column: 2 / 4;">
                                        <label class="component-label" for="max-scale">Max Scale</label>
                                        <select id="max-scale" class="component-select" style="width: 100%;" 
                                                data-tooltip="Typography scale ratio for larger screens - how dramatic the size differences should be on big screens">
                                            <option value="1.067" <?php selected($settings['maxScale'], '1.067'); ?>>1.067 Minor Second</option>
                                            <option value="1.125" <?php selected($settings['maxScale'], '1.125'); ?>>1.125 Major Second</option>
                                            <option value="1.200" <?php selected($settings['maxScale'], '1.200'); ?>>1.200 Minor Third</option>
                                            <option value="1.250" <?php selected($settings['maxScale'], '1.250'); ?>>1.250 Major Third</option>
                                            <option value="1.333" <?php selected($settings['maxScale'], '1.333'); ?>>1.333 Perfect Fourth</option>
                                            <option value="1.414" <?php selected($settings['maxScale'], '1.414'); ?>>1.414 Augmented Fourth</option>
                                            <option value="1.500" <?php selected($settings['maxScale'], '1.500'); ?>>1.500 Perfect Fifth</option>
                                            <option value="1.618" <?php selected($settings['maxScale'], '1.618'); ?>>1.618 Golden Ratio</option>
                                            <option value="1.667" <?php selected($settings['maxScale'], '1.667'); ?>>1.667 Major Sixth</option>
                                            <option value="1.778" <?php selected($settings['maxScale'], '1.778'); ?>>1.778 Minor Seventh</option>
                                            <option value="1.875" <?php selected($settings['maxScale'], '1.875'); ?>>1.875 Major Seventh</option>
                                            <option value="2.000" <?php selected($settings['maxScale'], '2.000'); ?>>2.000 Octave</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Column 2: Font Size Classes (Data Table) -->
                        <div>
                            <div class="fcc-panel" id="sizes-table-container">
                                <h2 style="margin-bottom: 12px;" id="table-title">Font Size Classes</h2>
                                <div class="fcc-table-buttons" id="table-action-buttons" style="margin-bottom: 16px;">
                                    <!-- Segment C will populate these buttons -->
                                    <div style="color: var(--jimr-secondary); font-size: 12px; font-style: italic;">Loading...</div>
                                </div>
                                <div id="sizes-table-wrapper">
                                    <!-- Segment C will populate the table -->
                                    <div style="text-align: center; color: var(--jimr-text); font-style: italic; padding: 40px;">
                                        <div class="fcc-loading-spinner" style="width: 30px; height: 30px; margin: 0 auto 10px;"></div>
                                        <div>Loading enhanced features...</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- ENHANCED: Full-Width Preview Section -->
                    <div class="fcc-preview-enhanced">
                        <div class="fcc-preview-header-row">
                            <h2 style="color: var(--jimr-primary); margin: 0;">Font Preview</h2>
                        </div>

                        <div class="fcc-preview-grid">
                            <div class="fcc-preview-column">
                                <div class="fcc-preview-column-header">
                                    <h3>Min Size (Small Screens)</h3>
                                    <div class="fcc-scale-indicator" id="min-viewport-display"><?php echo esc_html($settings['minViewport']); ?>px</div>
                                </div>
                                <div id="preview-min-container" style="background: white; border-radius: 8px; padding: 20px; border: 2px solid var(--jimr-secondary); min-height: 320px; box-shadow: inset 0 2px 4px var(--jimr-shadow);">
                                    <!-- Segment C will populate preview content -->
                                    <div style="text-align: center; color: var(--jimr-text); font-style: italic; padding: 60px 20px;">
                                        <div class="fcc-loading-spinner" style="width: 25px; height: 25px; margin: 0 auto 10px;"></div>
                                        <div>Loading preview...</div>
                                    </div>
                                </div>
                            </div>

                            <div class="fcc-preview-column">
                                <div class="fcc-preview-column-header">
                                    <h3>Max Size (Large Screens)</h3>
                                    <div class="fcc-scale-indicator" id="max-viewport-display"><?php echo esc_html($settings['maxViewport']); ?>px</div>
                                </div>
                                <div id="preview-max-container" style="background: white; border-radius: 8px; padding: 20px; border: 2px solid var(--jimr-secondary); min-height: 320px; box-shadow: inset 0 2px 4px var(--jimr-shadow);">
                                    <!-- Segment C will populate preview content -->
                                    <div style="text-align: center; color: var(--jimr-text); font-style: italic; padding: 60px 20px;">
                                        <div class="fcc-loading-spinner" style="width: 25px; height: 25px; margin: 0 auto 10px;"></div>
                                        <div>Loading preview...</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Enhanced CSS Output Containers -->
                    <div class="fcc-panel" style="margin-top: 8px;" id="selected-css-container">
                        <div class="fcc-css-header">
                            <h2 style="flex-grow: 1;" id="selected-code-title">Selected Class CSS</h2>
                            <div id="selected-copy-button">
                                <!-- Segment D will populate copy button -->
                            </div>
                        </div>
                        <div style="background: white; border-radius: 6px; padding: 8px; border: 1px solid #d1d5db;">
                            <pre id="class-code" style="font-size: 12px; white-space: pre-wrap; color: #111827; margin: 0;">/* Loading CSS output... */</pre>
                        </div>
                    </div>

                    <div class="fcc-panel" style="margin-top: 8px;" id="generated-css-container">
                        <div class="fcc-css-header">
                            <h2 style="flex-grow: 1;" id="generated-code-title">Generated CSS (All Classes)</h2>
                            <div class="fcc-css-buttons" id="generated-copy-buttons">
                                <!-- Segment D will populate copy buttons -->
                            </div>
                        </div>
                        <div style="background: white; border-radius: 6px; padding: 8px; border: 1px solid #d1d5db; overflow: auto; max-height: 300px;">
                            <pre id="generated-code" style="font-size: 12px; white-space: pre-wrap; color: #111827; margin: 0;">/* Loading CSS output... */</pre>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Enhanced Core JavaScript - WITH WORKING TOOLTIPS -->
            <script>
                // Simple JavaScript Tooltips - WORKING VERSION
                class SimpleTooltips {
                    constructor() {
                        this.tooltip = null;
                        this.init();
                        console.log('✅ JavaScript tooltips initialized');
                    }
                    
                    init() {
                        document.addEventListener('mouseover', (e) => {
                            if (e.target.dataset.tooltip) {
                                this.showTooltip(e.target, e.target.dataset.tooltip);
                            }
                        });
                        
                        document.addEventListener('mouseout', (e) => {
                            if (e.target.dataset.tooltip) {
                                this.hideTooltip();
                            }
                        });
                    }
                    
                    showTooltip(element, text) {
                        this.hideTooltip();
                        
                        this.tooltip = document.createElement('div');
                        this.tooltip.style.cssText = `
                            position: absolute;
                            background: #333;
                            color: white;
                            padding: 8px 12px;
                            border-radius: 4px;
                            font-size: 12px;
                            white-space: nowrap;
                            z-index: 99999;
                            pointer-events: none;
                            box-shadow: 0 2px 8px rgba(0,0,0,0.3);
                        `;
                        this.tooltip.textContent = text;
                        document.body.appendChild(this.tooltip);
                        
                        const rect = element.getBoundingClientRect();
                        const tooltipRect = this.tooltip.getBoundingClientRect();
                        
                        let left = rect.left + rect.width / 2 - tooltipRect.width / 2;
                        let top = rect.top - tooltipRect.height - 8;
                        
                        // Keep tooltip on screen
                        if (left < 5) left = 5;
                        if (left + tooltipRect.width > window.innerWidth - 5) {
                            left = window.innerWidth - tooltipRect.width - 5;
                        }
                        if (top < 5) {
                            top = rect.bottom + 8; // Show below if no room above
                        }
                        
                        this.tooltip.style.left = left + 'px';
                        this.tooltip.style.top = top + 'px';
                    }
                    
                    hideTooltip() {
                        if (this.tooltip) {
                            this.tooltip.remove();
                            this.tooltip = null;
                        }
                    }
                }

                // Enhanced Core Interface Controller (Segment B) - WITH CONSTANTS
                class FontClampEnhancedCoreInterface {
                    constructor() {
                        console.log('🚀 Font Clamp Calculator v3.5 - Enhanced UI/UX with Constants Integration!');
                        console.log('🚀 Segment B (Enhanced Core Interface) loaded - No Magic Numbers!');

                        this.initializeData();
                        this.cacheElements();
                        this.bindBasicEvents();
                        this.bindEnhancedEvents();
                        this.bindToggleEvents();
                        this.triggerSegmentHooks();
                        this.syncVisualState();

                        // FLASH FIX: Start loading sequence
                        this.initLoadingSequence();
                    }

                    bindToggleEvents() {
                        // Wait for DOM to be fully ready
                        setTimeout(() => {
                            // Info toggle
                            const infoToggle = document.querySelector('[data-toggle-target="info-content"]');
                            if (infoToggle) {
                                infoToggle.addEventListener('click', () => this.toggleInfo());
                            }

                            // About toggle  
                            const aboutToggle = document.querySelector('[data-toggle-target="about-content"]');
                            if (aboutToggle) {
                                aboutToggle.addEventListener('click', () => this.toggleAbout());
                            }
                        }, 100);
                    }

                    /**
                     * Toggle info section visibility
                     */
                    toggleInfo() {
                        const button = document.querySelector('[data-toggle-target="info-content"]');
                        const content = document.getElementById('info-content');

                        if (content && button) {
                            if (content.classList.contains('expanded')) {
                                content.classList.remove('expanded');
                                button.classList.remove('expanded');
                            } else {
                                content.classList.add('expanded');
                                button.classList.add('expanded');
                            }
                        }
                    }

                    /**
                     * Toggle about section visibility
                     */
                    toggleAbout() {
                        const button = document.querySelector('[data-toggle-target="about-content"]');
                        const content = document.getElementById('about-content');

                        if (content && button) {
                            if (content.classList.contains('expanded')) {
                                content.classList.remove('expanded');
                                button.classList.remove('expanded');
                            } else {
                                content.classList.add('expanded');
                                button.classList.add('expanded');
                            }
                        }
                    }

                    // FLASH FIX: Loading sequence management
                    initLoadingSequence() {
                        console.log('⏳ Starting enhanced loading sequence...');

                        this.loadingSteps = {
                            coreReady: false,
                            advancedReady: false,
                            contentPopulated: false
                        };

                        // Listen for Segment C ready
                        window.addEventListener('fontClampAdvancedReady', () => {
                            console.log('✅ Advanced features ready');
                            this.loadingSteps.advancedReady = true;
                            this.checkAndRevealInterface();
                        });

                        // Listen for content population events
                        window.addEventListener('fontClamp_dataUpdated', () => {
                            console.log('✅ Content populated');
                            this.loadingSteps.contentPopulated = true;
                            this.checkAndRevealInterface();
                        });

                        // Fallback timeout to prevent infinite loading
                        setTimeout(() => {
                            if (!this.isInterfaceRevealed()) {
                                console.log('⚠️ Fallback: Revealing enhanced interface after timeout');
                                this.revealInterface();
                            }
                        }, 5000);
                    }

                    checkAndRevealInterface() {
                        // Wait for both advanced features and content population
                        if (this.loadingSteps.advancedReady && this.loadingSteps.contentPopulated) {
                            console.log('🎉 All loading steps complete - revealing enhanced interface');
                            setTimeout(() => this.revealInterface(), 300);
                        }
                    }

                    revealInterface() {
                        if (this.isInterfaceRevealed()) return;

                        console.log('🎭 Revealing enhanced interface...');

                        // Hide loading screen
                        const loadingScreen = document.getElementById('fcc-loading-screen');
                        if (loadingScreen) {
                            loadingScreen.classList.add('hidden');
                        }

                        // Show main container
                        const mainContainer = document.getElementById('fcc-main-container');
                        if (mainContainer) {
                            mainContainer.classList.add('ready');
                        }

                        // Update autosave status
                        const autosaveIcon = document.getElementById('autosave-icon');
                        const autosaveText = document.getElementById('autosave-text');
                        if (autosaveIcon && autosaveText) {
                            autosaveIcon.textContent = '💾';
                            autosaveText.textContent = 'Ready';
                        }

                        console.log('✨ Enhanced interface revealed successfully!');
                    }

                    isInterfaceRevealed() {
                        const mainContainer = document.getElementById('fcc-main-container');
                        return mainContainer && mainContainer.classList.contains('ready');
                    }

                    syncVisualState() {
                        // Ensure visual tab state matches data
                        document.querySelectorAll('[data-tab]').forEach(tab => {
                            tab.classList.remove('active');
                        });
                        document.querySelector(`[data-tab="${this.activeTab}"]`)?.classList.add('active');

                        console.log('🔄 Enhanced visual state synced to tab:', this.activeTab);
                    }

                    initializeData() {
                        // Core data from Segment A
                        this.settings = <?php echo json_encode($settings); ?>;
                        this.classSizes = <?php echo json_encode($class_sizes); ?>;
                        this.variableSizes = <?php echo json_encode($variable_sizes); ?>;
                        this.tagSizes = <?php echo json_encode($tag_sizes); ?>;

                        this.activeTab = this.settings.activeTab || 'class';
                        this.unitType = this.settings.unitType || 'px';
                    }

                    cacheElements() {
                        this.elements = {
                            classTab: document.getElementById('class-tab'),
                            varsTab: document.getElementById('vars-tab'),
                            tagTab: document.getElementById('tag-tab'),
                            pxTab: document.getElementById('px-tab'),
                            remTab: document.getElementById('rem-tab'),
                            tableTitle: document.getElementById('table-title'),
                            selectedCodeTitle: document.getElementById('selected-code-title'),
                            generatedCodeTitle: document.getElementById('generated-code-title'),
                            // More elements for Segments C & D to use
                            previewMinContainer: document.getElementById('preview-min-container'),
                            previewMaxContainer: document.getElementById('preview-max-container'),
                            sizesTableWrapper: document.getElementById('sizes-table-wrapper'),
                            classCode: document.getElementById('class-code'),
                            generatedCode: document.getElementById('generated-code'),
                            minViewportDisplay: document.getElementById('min-viewport-display'),
                            maxViewportDisplay: document.getElementById('max-viewport-display')
                        };
                    }

                    bindBasicEvents() {
                        // Basic tab switching
                        this.elements.classTab?.addEventListener('click', () => this.switchTab('class'));
                        this.elements.varsTab?.addEventListener('click', () => this.switchTab('vars'));
                        this.elements.tagTab?.addEventListener('click', () => this.switchTab('tag'));

                        // Basic unit switching
                        this.elements.pxTab?.addEventListener('click', () => this.switchUnitType('px'));
                        this.elements.remTab?.addEventListener('click', () => this.switchUnitType('rem'));

                        // FIXED: Add input change events
                        document.getElementById('min-root-size')?.addEventListener('input', () => this.triggerCalculation());
                        document.getElementById('max-root-size')?.addEventListener('input', () => this.triggerCalculation());
                        document.getElementById('min-viewport')?.addEventListener('input', () => this.triggerCalculation());
                        document.getElementById('max-viewport')?.addEventListener('input', () => this.triggerCalculation());
                        document.getElementById('min-scale')?.addEventListener('change', () => this.triggerCalculation());
                        document.getElementById('max-scale')?.addEventListener('change', () => this.triggerCalculation());

                        console.log('🔗 Basic events bound');
                    }
                    
                    triggerCalculation() {
                        // Trigger recalculation in Segment C
                        window.dispatchEvent(new CustomEvent('fontClamp_settingsChanged'));
                        if (window.fontClampAdvanced && window.fontClampAdvanced.calculateSizes) {
                            window.fontClampAdvanced.calculateSizes();
                        }
                    }
                    
                    bindEnhancedEvents() {
                        // Update viewport displays when inputs change
                        document.getElementById('min-viewport')?.addEventListener('input', (e) => {
                            if (this.elements.minViewportDisplay) {
                                this.elements.minViewportDisplay.textContent = e.target.value + 'px';
                            }
                        });

                        document.getElementById('max-viewport')?.addEventListener('input', (e) => {
                            if (this.elements.maxViewportDisplay) {
                                this.elements.maxViewportDisplay.textContent = e.target.value + 'px';
                            }
                        });

                        console.log('🎨 Enhanced events bound');
                    }

                    switchTab(tabName) {
                        console.log('🔄 Enhanced tab switching to:', tabName);
                        this.activeTab = tabName;

                        // Update tab buttons with enhanced animations
                        document.querySelectorAll('[data-tab]').forEach(tab => {
                            tab.classList.remove('active');
                        });
                        document.querySelector(`[data-tab="${tabName}"]`)?.classList.add('active');

                        // Update titles
                        if (tabName === 'class') {
                            this.elements.tableTitle.textContent = 'Font Size Classes';
                            this.elements.selectedCodeTitle.textContent = 'Selected Class CSS';
                            this.elements.generatedCodeTitle.textContent = 'Generated CSS (All Classes)';
                        } else if (tabName === 'vars') {
                            this.elements.tableTitle.textContent = 'CSS Variables';
                            this.elements.selectedCodeTitle.textContent = 'Selected Variable CSS';
                            this.elements.generatedCodeTitle.textContent = 'Generated CSS (All Variables)';
                        } else if (tabName === 'tag') {
                            this.elements.tableTitle.textContent = 'HTML Tag Styles';
                            this.elements.selectedCodeTitle.textContent = 'Selected Tag CSS';
                            this.elements.generatedCodeTitle.textContent = 'Generated CSS (All Tags)';
                        }

                        // Trigger hook for advanced features
                        this.triggerHook('tabChanged', {
                            activeTab: tabName
                        });
                    }

                    switchUnitType(unitType) {
                        console.log('🔄 Enhanced unit type switching to:', unitType);
                        this.unitType = unitType;

                        // Update unit buttons with enhanced animations
                        document.querySelectorAll('[data-unit]').forEach(btn => {
                            btn.classList.remove('active');
                        });
                        document.querySelector(`[data-unit="${unitType}"]`)?.classList.add('active');

                        // Trigger hook for advanced features
                        this.triggerHook('unitTypeChanged', {
                            unitType: unitType
                        });
                    }

                    // Hook system for Segments C & D
                    triggerSegmentHooks() {
                        // Let other segments know the enhanced core interface is ready
                        window.dispatchEvent(new CustomEvent('fontClampCoreReady', {
                            detail: {
                                coreInterface: this,
                                data: {
                                    settings: this.settings,
                                    classSizes: this.classSizes,
                                    variableSizes: this.variableSizes,
                                    tagSizes: this.tagSizes
                                },
                                elements: this.elements
                            }
                        }));

                        console.log('🚀 Enhanced core ready event triggered for Segments C & D');
                    }

                    triggerHook(hookName, data) {
                        window.dispatchEvent(new CustomEvent(`fontClamp_${hookName}`, {
                            detail: {
                                ...data,
                                coreInterface: this
                            }
                        }));
                    }

                    // Public API for other segments
                    getCurrentSizes() {
                        return this.activeTab === 'class' ? this.classSizes :
                            this.activeTab === 'vars' ? this.variableSizes : this.tagSizes;
                    }

                    updateData(newData) {
                        Object.assign(this, newData);
                        this.triggerHook('dataUpdated', newData);
                    }
                }

                // Initialize tooltips first
                new SimpleTooltips();

                // Initialize when DOM is ready
                document.addEventListener('DOMContentLoaded', () => {
                    window.fontClampCore = new FontClampEnhancedCoreInterface();
                });
            </script>
        </div>
<?php

        // Return the buffered content to replace Segment A's placeholder
        return ob_get_clean();
    }
} else {
    // Segment A not loaded - add admin notice
    add_action('admin_notices', function () {
        echo '<div class="notice notice-error"><p><strong>Font Clamp Calculator Segment B:</strong> Cannot load - Segment A (Foundation) not found. Please load Segment A first.</p></div>';
    });
}
?>