<?php

/**
 * Font Clamp Calculator - Segment C 
 * Version: 3.5 - Advanced Features 
 * 
 * Enhanced with complete constant system integration:
 * - All viewport defaults use constants
 * - All font size defaults use constants  
 * - All line height defaults use constants
 * - Browser defaults use constants
 * - Validation ranges use constants
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Advanced Features Controller Class - NO MAGIC NUMBERS
 */
class FontClampAdvancedFeatures
{
    private $version = '3.5.0';
    private $data = [];
    private $settings = [];
    private $original_defaults = [];
    private $constants = null;
    private $assets_loaded = false;
    private $next_ids = ['class' => 1, 'vars' => 1, 'tag' => 1];
    private $selected_ids = ['class' => 5, 'vars' => 5, 'tag' => 1];

    public function __construct()
    {
        if (!class_exists('FontClampCalculator')) {
            add_action('admin_notices', [$this, 'show_dependency_notice']);
        }
        $this->init();
    }

    /**
     * ENHANCED: Get constants with complete system integration
     */
    private function getCalculatorConstants()
    {
        if ($this->constants !== null) {
            return $this->constants;
        }

        if (class_exists('FontClampCalculator')) {
            // Get the global instance
            global $fontClampCalculator;
            if ($fontClampCalculator && method_exists($fontClampCalculator, 'get_all_constants')) {
                $this->constants = $fontClampCalculator->get_all_constants();
                error_log('✅ Magic Number Fix: Using complete constants from FontClampCalculator');
            } else {
                // Fallback to class constants if method not available
                $this->constants = [
                    'DEFAULT_MIN_ROOT_SIZE' => FontClampCalculator::DEFAULT_MIN_ROOT_SIZE,
                    'DEFAULT_MAX_ROOT_SIZE' => FontClampCalculator::DEFAULT_MAX_ROOT_SIZE,
                    'DEFAULT_MIN_VIEWPORT' => FontClampCalculator::DEFAULT_MIN_VIEWPORT,
                    'DEFAULT_MAX_VIEWPORT' => FontClampCalculator::DEFAULT_MAX_VIEWPORT,
                    'DEFAULT_LINE_HEIGHT' => FontClampCalculator::DEFAULT_LINE_HEIGHT,
                    'DEFAULT_HEADING_LINE_HEIGHT' => FontClampCalculator::DEFAULT_HEADING_LINE_HEIGHT,
                    'DEFAULT_BODY_LINE_HEIGHT' => FontClampCalculator::DEFAULT_BODY_LINE_HEIGHT,
                    'DEFAULT_MIN_SCALE' => FontClampCalculator::DEFAULT_MIN_SCALE,
                    'DEFAULT_MAX_SCALE' => FontClampCalculator::DEFAULT_MAX_SCALE,
                    'BROWSER_DEFAULT_FONT_SIZE' => FontClampCalculator::BROWSER_DEFAULT_FONT_SIZE,
                    'CSS_UNIT_CONVERSION_BASE' => FontClampCalculator::CSS_UNIT_CONVERSION_BASE,
                    'MIN_ROOT_SIZE_RANGE' => FontClampCalculator::MIN_ROOT_SIZE_RANGE,
                    'VIEWPORT_RANGE' => FontClampCalculator::VIEWPORT_RANGE,
                    'LINE_HEIGHT_RANGE' => FontClampCalculator::LINE_HEIGHT_RANGE,
                    'SCALE_RANGE' => FontClampCalculator::SCALE_RANGE,
                    'VALID_UNITS' => FontClampCalculator::VALID_UNITS,
                    'VALID_TABS' => FontClampCalculator::VALID_TABS
                ];
                error_log('✅ Magic Number Fix: Using fallback constants from FontClampCalculator class');
            }
        } else {
            // Ultimate fallback - should never be needed with proper setup
            $this->constants = [
                'DEFAULT_MIN_ROOT_SIZE' => 16,
                'DEFAULT_MAX_ROOT_SIZE' => 20,
                'DEFAULT_MIN_VIEWPORT' => 375,
                'DEFAULT_MAX_VIEWPORT' => 1620,
                'DEFAULT_LINE_HEIGHT' => 1.4,
                'DEFAULT_HEADING_LINE_HEIGHT' => 1.2,
                'DEFAULT_BODY_LINE_HEIGHT' => 1.4,
                'DEFAULT_MIN_SCALE' => 1.125,
                'DEFAULT_MAX_SCALE' => 1.333,
                'BROWSER_DEFAULT_FONT_SIZE' => 16,
                'CSS_UNIT_CONVERSION_BASE' => 16,
                'MIN_ROOT_SIZE_RANGE' => [1, 100],
                'VIEWPORT_RANGE' => [200, 5000],
                'LINE_HEIGHT_RANGE' => [0.8, 3.0],
                'SCALE_RANGE' => [1.0, 3.0],
                'VALID_UNITS' => ['px', 'rem'],
                'VALID_TABS' => ['class', 'vars', 'tag']
            ];
            error_log('⚠️ Magic Number Fix: Using ultimate fallback constants');
        }
        
        return $this->constants;
    }

    private function init()
    {
        try {
            $this->load_data();
            $this->store_original_defaults();
            $this->calculate_next_ids();
            $this->setup_hooks();

            if ($this->is_plugin_page()) {
                $this->init_display();
            }
        } catch (Exception $e) {
            $this->log_error('Initialization failed', $e);
            add_action('admin_notices', [$this, 'show_error_notice']);
        }
    }

    /**
     * ENHANCED: Load data using proper constants
     */
    private function load_data()
    {
        $constants = $this->getCalculatorConstants();
        
        $this->data = [
            'classSizes' => get_option('font_clamp_class_sizes', $this->get_default_class_sizes()),
            'variableSizes' => get_option('font_clamp_variable_sizes', $this->get_default_variable_sizes()),
            'tagSizes' => get_option('font_clamp_tag_sizes', $this->get_default_tag_sizes())
        ];

        // FIXED: Load settings using proper constants instead of magic numbers
        $this->settings = get_option('font_clamp_settings', [
            'minRootSize' => $constants['DEFAULT_MIN_ROOT_SIZE'],
            'maxRootSize' => $constants['DEFAULT_MAX_ROOT_SIZE'],
            'minViewport' => $constants['DEFAULT_MIN_VIEWPORT'],
            'maxViewport' => $constants['DEFAULT_MAX_VIEWPORT'],
            'minScale' => $constants['DEFAULT_MIN_SCALE'],
            'maxScale' => $constants['DEFAULT_MAX_SCALE'],
            'unitType' => 'rem',
            'activeTab' => 'class',
            'autosaveEnabled' => true,
            'classBaseValue' => 'medium',
            'varsBaseValue' => '--fs-md',
            'tagBaseValue' => 'p'
        ]);
        
        error_log('✅ Magic Number Fix: Settings loaded with constants');
    }

    private function store_original_defaults()
    {
        $this->original_defaults = [
            'classSizes' => $this->get_default_class_sizes(),
            'variableSizes' => $this->get_default_variable_sizes(),
            'tagSizes' => $this->get_default_tag_sizes()
        ];
    }

    private function calculate_next_ids()
    {
        $class_ids = !empty($this->data['classSizes']) ? array_map(function ($size) {
            return $size['id'];
        }, $this->data['classSizes']) : [0];
        $var_ids = !empty($this->data['variableSizes']) ? array_map(function ($size) {
            return $size['id'];
        }, $this->data['variableSizes']) : [0];
        $tag_ids = !empty($this->data['tagSizes']) ? array_map(function ($size) {
            return $size['id'];
        }, $this->data['tagSizes']) : [0];

        $this->next_ids['class'] = max($class_ids) + 1;
        $this->next_ids['vars'] = max($var_ids) + 1;
        $this->next_ids['tag'] = max($tag_ids) + 1;
    }

    private function setup_hooks()
    {
        add_action('admin_footer', [$this, 'render_assets'], 20);
        add_action('wp_ajax_save_font_clamp_sizes', [$this, 'handle_ajax_save']);
        add_action('admin_init', [$this, 'admin_init']);
    }

    private function is_plugin_page()
    {
        return isset($_GET['page']) && sanitize_text_field($_GET['page']) === 'font-clamp-calculator';
    }

    private function init_display()
    {
        if (!$this->is_plugin_page()) {
            return;
        }
        add_action('admin_footer', [$this, 'init_javascript'], 25);
    }

    public function admin_init()
    {
        // Any admin-specific initialization
    }

    public function render_assets()
    {
        if (!$this->is_plugin_page() || $this->assets_loaded) {
            return;
        }

        if (!$this->should_load_assets()) {
            return;
        }

        $this->render_scripts();
        $this->assets_loaded = true;
    }

    private function should_load_assets()
    {
        return true;
    }

    /**
     * ENHANCED: JavaScript with complete constants integration
     */
    private function render_scripts()
    {
?><script>

/**
 * Font Clamp Advanced Features Controller - COMPLETE MAGIC NUMBER ELIMINATION
 * All constants now properly sourced from PHP backend
 */
class FontClampAdvanced {
    constructor() {
        this.version = '3.5.0';
        this.DEBUG_MODE = true;
        this.initialized = false;
        this.dragState = this.initDragState();
        this.editingId = null;
        this.lastFontStyle = null;
        this.dataChanged = false;
        
        // Initialize constants from backend
        this.constants = this.initializeConstants();
        
        this.initState = {
            domReady: false,
            dataReady: false,
            segmentBReady: false
        };

        this.updatePreview = this.debounce(this.updatePreview.bind(this), 150);
        this.calculateSizes = this.debounce(this.calculateSizes.bind(this), 300);

        console.log('🎯 Magic Number Fix: Enhanced constructor with complete constants system');
        
        this.initializeWhenReady();
    }

    /**
     * NEW: Initialize constants from backend - NO MORE MAGIC NUMBERS
     */
    initializeConstants() {
        // Priority 1: Use constants from Segment A
        if (window.fontClampAjax && window.fontClampAjax.constants) {
            console.log('✅ Magic Number Fix: Using constants from Segment A');
            return window.fontClampAjax.constants;
        }
        
        // Priority 2: Use defaults from Segment A
        if (window.fontClampAjax && window.fontClampAjax.defaults) {
            console.log('⚠️ Magic Number Fix: Using defaults from Segment A (partial)');
            return {
                DEFAULT_MIN_ROOT_SIZE: window.fontClampAjax.defaults.minRootSize || 16,
                DEFAULT_MAX_ROOT_SIZE: window.fontClampAjax.defaults.maxRootSize || 20,
                DEFAULT_MIN_VIEWPORT: window.fontClampAjax.defaults.minViewport || 375,
                DEFAULT_MAX_VIEWPORT: window.fontClampAjax.defaults.maxViewport || 1620,
                DEFAULT_LINE_HEIGHT: 1.4,
                DEFAULT_HEADING_LINE_HEIGHT: 1.2,
                DEFAULT_BODY_LINE_HEIGHT: 1.4,
                BROWSER_DEFAULT_FONT_SIZE: 16,
                CSS_UNIT_CONVERSION_BASE: 16
            };
        }
        
        // Priority 3: Ultimate fallback (should never be reached)
        console.log('❌ Magic Number Fix: Using ultimate fallback constants');
        return {
            DEFAULT_MIN_ROOT_SIZE: 16,
            DEFAULT_MAX_ROOT_SIZE: 20,
            DEFAULT_MIN_VIEWPORT: 375,
            DEFAULT_MAX_VIEWPORT: 1620,
            DEFAULT_LINE_HEIGHT: 1.4,
            DEFAULT_HEADING_LINE_HEIGHT: 1.2,
            DEFAULT_BODY_LINE_HEIGHT: 1.4,
            BROWSER_DEFAULT_FONT_SIZE: 16,
            CSS_UNIT_CONVERSION_BASE: 16
        };
    }

    initializeWhenReady() {
        console.log('🎯 Magic Number Fix: Enhanced initialization sequence starting...');
        
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => {
                this.initState.domReady = true;
                this.checkReadinessAndInit();
            });
        } else {
            this.initState.domReady = true;
        }

        if (window.fontClampData || (window.fontClampAjax && window.fontClampAjax.data)) {
            this.initState.dataReady = true;
        } else {
            window.addEventListener('fontClampDataReady', () => {
                this.initState.dataReady = true;
                this.checkReadinessAndInit();
            });
        }

        if (window.fontClampCore) {
            this.initState.segmentBReady = true;
        } else {
            window.addEventListener('fontClampCoreReady', () => {
                this.initState.segmentBReady = true;
                this.checkReadinessAndInit();
            });
        }

        this.checkReadinessAndInit();

        setTimeout(() => {
            if (!this.initialized) {
                console.log('🎯 Magic Number Fix: Fallback initialization after timeout');
                this.forceInit();
            }
        }, 2000);
    }

    checkReadinessAndInit() {
        const { domReady, dataReady, segmentBReady } = this.initState;
        
        if (domReady && dataReady && segmentBReady && !this.initialized) {
            console.log('🎯 Magic Number Fix: All prerequisites met - initializing!');
            setTimeout(() => this.init(), 50);
        }
    }

    forceInit() {
        if (!this.initialized) {
            console.log('🎯 Magic Number Fix: Force initializing with available resources');
            this.init();
        }
    }

    log(message, ...args) {
        if (this.DEBUG_MODE) {
            console.log(`[FontClamp] ${message}`, ...args);
        }
    }

    initDragState() {
        return {
            isDragging: false,
            draggedRow: null,
            startY: 0,
            currentY: 0,
            offset: 0
        };
    }

    init() {
        try {
            console.log('🎯 Magic Number Fix: Font Clamp Advanced Features - Complete Constants Integration!');

            this.cacheElements();
            this.bindEvents();
            this.setupTableActions();
            this.setupModal();
            this.setupGlobalDragHandler();
            this.initializeDisplay();

            this.initialized = true;

            window.dispatchEvent(new CustomEvent('fontClampAdvancedReady', {
                detail: {
                    advancedFeatures: this,
                    version: this.version
                }
            }));

        } catch (error) {
            console.error('❌ Failed to initialize Font Clamp Advanced Features:', error);
            this.showError('Failed to initialize advanced features');
        }
    }

    setupGlobalDragHandler() {
        document.addEventListener('dragover', (e) => {
            if (this.dragState.isDragging) {
                e.preventDefault();
                const target = e.target.closest('.size-row');
                if (target && target !== this.dragState.draggedRow) {
                    this.log('Global dragover detected');
                }
            }
        });
    }

    cacheElements() {
        this.elements = {
            minRootSizeInput: document.getElementById('min-root-size'),
            maxRootSizeInput: document.getElementById('max-root-size'),
            baseValueSelect: document.getElementById('base-value'),
            minViewportInput: document.getElementById('min-viewport'),
            maxViewportInput: document.getElementById('max-viewport'),
            minScaleSelect: document.getElementById('min-scale'),
            maxScaleSelect: document.getElementById('max-scale'),
            previewFontUrlInput: document.getElementById('preview-font-url'),
            fontFilenameSpan: document.getElementById('font-filename'),
            autosaveStatus: document.getElementById('autosave-status'),
            autosaveIcon: document.getElementById('autosave-icon'),
            autosaveText: document.getElementById('autosave-text'),
            autosaveToggle: document.getElementById('autosave-toggle'),
            sizesTableWrapper: document.getElementById('sizes-table-wrapper'),
            previewMinContainer: document.getElementById('preview-min-container'),
            previewMaxContainer: document.getElementById('preview-max-container'),
            tableHeader: document.getElementById('table-header'),
            tableActionButtons: document.getElementById('table-action-buttons'),
            minViewportDisplay: document.getElementById('min-viewport-display'),
            maxViewportDisplay: document.getElementById('max-viewport-display')
        };
    }

    bindEvents() {
        const settingsInputs = [
            'minRootSizeInput', 'maxRootSizeInput', 'minViewportInput', 'maxViewportInput'
        ];

        settingsInputs.forEach(elementKey => {
            const element = this.elements[elementKey];
            if (element) {
                element.addEventListener('input', () => this.calculateSizes());
            }
        });

        const settingsSelects = [
            'baseValueSelect', 'minScaleSelect', 'maxScaleSelect'
        ];

        settingsSelects.forEach(elementKey => {
            const element = this.elements[elementKey];
            if (element) {
                element.addEventListener('change', () => this.calculateSizes());
            }
        });

        if (this.elements.previewFontUrlInput) {
            this.elements.previewFontUrlInput.addEventListener('input',
                this.debounce(() => this.updatePreviewFont(), 500)
            );
        }

        if (this.elements.autosaveToggle) {
            this.elements.autosaveToggle.addEventListener('change', () => {
                this.updateSettings();
            });
        }

        window.addEventListener('fontClamp_tabChanged', (e) => {
            this.handleTabChange(e.detail);
        });

        window.addEventListener('fontClamp_unitTypeChanged', () => {
            this.calculateSizes();
        });

        // FIXED: Update ROOT SIZE displays properly using constants
        document.getElementById('min-root-size')?.addEventListener('input', (e) => {
            if (this.elements.minViewportDisplay) {
                this.elements.minViewportDisplay.textContent = e.target.value + 'px';
            }
        });

        document.getElementById('max-root-size')?.addEventListener('input', (e) => {
            if (this.elements.maxViewportDisplay) {
                this.elements.maxViewportDisplay.textContent = e.target.value + 'px';
            }
        });
    }

    setupTableActions() {
        const tableButtons = this.elements.tableActionButtons;
        if (!tableButtons) return;

        tableButtons.innerHTML = `
            <button id="add-size" class="fcc-btn">Add Size</button>
            <button id="reset-defaults" class="fcc-btn">Reset</button>
            <button id="clear-sizes" class="fcc-btn fcc-btn-danger">Clear All</button>
        `;

        tableButtons.addEventListener('click', (e) => {
            const button = e.target.closest('button');
            if (!button) return;

            e.preventDefault();

            switch (button.id) {
                case 'add-size':
                    this.addNewSize();
                    break;
                case 'reset-defaults':
                    this.resetDefaults();
                    break;
                case 'clear-sizes':
                    this.clearSizes();
                    break;
            }
        });
    }

    setupModal() {
        const existing = document.getElementById('edit-modal');
        if (existing) existing.remove();

        const modal = document.createElement('div');
        modal.id = 'edit-modal';
        modal.className = 'fcc-modal';
        modal.innerHTML = `
            <div class="fcc-modal-dialog">
                <div class="fcc-modal-header">
                    Edit Size
                    <button type="button" class="fcc-modal-close" aria-label="Close">&times;</button>
                </div>
                <div class="fcc-modal-content">
                    <div class="fcc-form-group" id="name-field">
                        <label class="fcc-label" for="edit-name">Name</label>
                        <input type="text" id="edit-name" class="fcc-input" required>
                    </div>
                    <div class="fcc-form-group">
                        <label class="fcc-label" for="edit-line-height">Line Height</label>
                        <input type="number" id="edit-line-height" class="fcc-input" 
                               step="0.1" min="${this.constants.LINE_HEIGHT_RANGE ? this.constants.LINE_HEIGHT_RANGE[0] : 0.8}" 
                               max="${this.constants.LINE_HEIGHT_RANGE ? this.constants.LINE_HEIGHT_RANGE[1] : 3.0}" required>
                    </div>
                    <div class="fcc-btn-group">
                        <button type="button" class="fcc-btn fcc-btn-ghost" id="modal-cancel">Cancel</button>
                        <button type="button" class="fcc-btn fcc-btn-primary" id="modal-save">Save</button>
                    </div>
                </div>
            </div>
        `;

        document.body.appendChild(modal);
        this.bindModalEvents(modal);
    }

    bindModalEvents(modal) {
        const closeBtn = modal.querySelector('.fcc-modal-close');
        const cancelBtn = modal.querySelector('#modal-cancel');
        const saveBtn = modal.querySelector('#modal-save');

        closeBtn.addEventListener('click', () => this.closeModal());
        cancelBtn.addEventListener('click', () => this.closeModal());

        modal.addEventListener('click', (e) => {
            if (e.target === modal) this.closeModal();
        });

        saveBtn.addEventListener('click', () => this.saveEdit());

        modal.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                this.saveEdit();
            } else if (e.key === 'Escape') {
                this.closeModal();
            }
        });
    }

    /**
     * FIXED: Initialize display with proper constants instead of magic numbers
     */
    initializeDisplay() {
        this.populateSettings();
        this.updateBaseValueOptions();

        // FIXED: Use constants instead of magic numbers
        const minViewportSize = this.elements.minViewportInput?.value || this.constants.DEFAULT_MIN_VIEWPORT;
        const maxViewportSize = this.elements.maxViewportInput?.value || this.constants.DEFAULT_MAX_VIEWPORT;

        if (this.elements.minViewportDisplay) {
            this.elements.minViewportDisplay.textContent = minViewportSize + 'px';
        }
        if (this.elements.maxViewportDisplay) {
            this.elements.maxViewportDisplay.textContent = maxViewportSize + 'px';
        }

        this.calculateSizes();
        this.renderSizes();
        this.updatePreviewFont();
        this.updatePreview();

        this.log('Display initialization complete with constants');
    }

    /**
     * ENHANCED: Populate settings using constants instead of magic numbers
     */
    populateSettings() {
        console.log('🎯 DEBUG populateSettings with constants:');
        console.log('  constants:', this.constants);
        
        if (!window.fontClampData && !window.fontClampAjax?.data) {
            console.log('⏳ Data not ready, waiting...');
            setTimeout(() => this.populateSettings(), 100);
            return;
        }

        const data = window.fontClampData || window.fontClampAjax?.data;
        
        if (!data) {
            console.error('❌ No font clamp data available after wait!');
            return;
        }

        // FIXED: Use constants instead of magic numbers for validation
        const minRootSize = data.settings?.minRootSize || this.constants.DEFAULT_MIN_ROOT_SIZE;
        const maxRootSize = data.settings?.maxRootSize || this.constants.DEFAULT_MAX_ROOT_SIZE;
        const minViewport = data.settings?.minViewport || this.constants.DEFAULT_MIN_VIEWPORT;
        const maxViewport = data.settings?.maxViewport || this.constants.DEFAULT_MAX_VIEWPORT;

        console.log('✅ Validated values using constants:', { minRootSize, maxRootSize, minViewport, maxViewport });

        if (this.elements.minRootSizeInput) {
            this.elements.minRootSizeInput.value = minRootSize;
        }
        if (this.elements.maxRootSizeInput) {
            this.elements.maxRootSizeInput.value = maxRootSize;
        }
        if (this.elements.minViewportInput) {
            this.elements.minViewportInput.value = minViewport;
        }
        if (this.elements.maxViewportInput) {
            this.elements.maxViewportInput.value = maxViewport;
        }

        if (this.elements.autosaveToggle) {
            this.elements.autosaveToggle.checked = data.settings?.autosaveEnabled !== false;
        }

        console.log('✅ Settings population complete using constants');
    }

    handleTabChange(detail) {
        this.log('Tab changed to:', detail.activeTab);

        this.updateTableHeaders();
        this.updateBaseValueOptions();

        setTimeout(() => {
            this.calculateSizes();
            this.renderSizes();
            this.updatePreview();
        }, 50);
    }

updateTableHeaders() {
    const headerRow = this.elements.tableHeader;
    if (!headerRow) return;

    const activeTab = window.fontClampCore?.activeTab || 'class';
    const nameHeader = headerRow.children[1];

    if (nameHeader) {
        switch (activeTab) {
            case 'class':
                nameHeader.innerHTML = 'Class';
                break;
            case 'vars':
                nameHeader.innerHTML = 'Variable';
                break;
            case 'tag':
                nameHeader.innerHTML = 'Tag';
                break;
        }
    }
}

    updateBaseValueOptions() {
        const select = this.elements.baseValueSelect;
        if (!select) return;

        const activeTab = window.fontClampCore?.activeTab || 'class';
        const sizes = this.getCurrentSizes();

        select.innerHTML = '';

        sizes.forEach(size => {
            const option = document.createElement('option');

            switch (activeTab) {
                case 'class':
                    option.value = size.className;
                    option.textContent = size.className;
                    if (size.className === 'medium') option.selected = true;
                    break;
                case 'vars':
                    option.value = size.variableName;
                    option.textContent = size.variableName;
                    if (size.variableName === '--fs-md') option.selected = true;
                    break;
                case 'tag':
                    option.value = size.tagName;
                    option.textContent = size.tagName;
                    if (size.tagName === 'p') option.selected = true;
                    break;
            }

            select.appendChild(option);
        });
    }

    /**
     * ENHANCED: Calculate sizes using constants instead of magic numbers
     */
    calculateSizes() {
        console.log('🎯 calculateSizes() using constants');
        
        const baseValue = this.elements.baseValueSelect?.value;
        if (!baseValue) {
            this.log('❌ No base value selected');
            return;
        }

        const sizes = this.getCurrentSizes();
        const baseSize = sizes.find(size => {
            const activeTab = window.fontClampCore?.activeTab || 'class';
            switch (activeTab) {
                case 'class':
                    return size.className === baseValue;
                case 'vars':
                    return size.variableName === baseValue;
                case 'tag':
                    return size.tagName === baseValue;
            }
        });

        if (!baseSize) {
            this.log('❌ Base size not found for:', baseValue);
            return;
        }

        const baseIndex = sizes.indexOf(baseSize);
        const minScale = parseFloat(this.elements.minScaleSelect?.value);
        const maxScale = parseFloat(this.elements.maxScaleSelect?.value);
        const minRootSize = parseFloat(this.elements.minRootSizeInput?.value);
        const maxRootSize = parseFloat(this.elements.maxRootSizeInput?.value);
        const unitType = window.fontClampCore?.unitType || 'rem';

        if (isNaN(minScale) || isNaN(maxScale) || isNaN(minRootSize) || isNaN(maxRootSize)) {
            this.log('❌ Invalid form values');
            return;
        }

        console.log('🎯 CALCULATION with constants:');
        console.log('  Constants available:', Object.keys(this.constants));
        console.log('  Using BROWSER_DEFAULT_FONT_SIZE:', this.constants.BROWSER_DEFAULT_FONT_SIZE);

        let minBaseSize, maxBaseSize;
        if (unitType === 'rem') {
            // FIXED: Use constant instead of magic number
            minBaseSize = minRootSize / this.constants.BROWSER_DEFAULT_FONT_SIZE;
            maxBaseSize = maxRootSize / this.constants.BROWSER_DEFAULT_FONT_SIZE;
        } else {
            minBaseSize = minRootSize;
            maxBaseSize = maxRootSize;
        }

        console.log('  Calculated base sizes:', { minBaseSize, maxBaseSize });

        if (sizes.length === 1) {
            sizes[0].min = parseFloat(minBaseSize.toFixed(3));
            sizes[0].max = parseFloat(maxBaseSize.toFixed(3));
        } else {
            sizes.forEach((size, index) => {
                const steps = baseIndex - index;
                const minMultiplier = Math.pow(minScale, steps);
                const maxMultiplier = Math.pow(maxScale, steps);

                const calculatedMin = minBaseSize * minMultiplier;
                const calculatedMax = maxBaseSize * maxMultiplier;

                size.min = parseFloat(calculatedMin.toFixed(3));
                size.max = parseFloat(calculatedMax.toFixed(3));
            });
        }

        this.dataChanged = true;
        this.renderSizes();
        this.updatePreview();
        this.updateCSS();
    }

    updatePreview() {
        console.log('🎯 updatePreview() using constants');
        try {
            const sizes = this.getCurrentSizes();
            const previewMin = this.elements.previewMinContainer;
            const previewMax = this.elements.previewMaxContainer;

            if (!previewMin || !previewMax) {
                return;
            }

            previewMin.innerHTML = '';
            previewMax.innerHTML = '';

            if (sizes.length === 0) {
                previewMin.innerHTML = '<div style="text-align: center; color: #6b7280; font-style: italic; padding: 60px 20px;">No sizes to preview</div>';
                previewMax.innerHTML = '<div style="text-align: center; color: #6b7280; font-style: italic; padding: 60px 20px;">No sizes to preview</div>';
                return;
            }

            const minRootSize = parseFloat(this.elements.minRootSizeInput?.value);
            const maxRootSize = parseFloat(this.elements.maxRootSizeInput?.value);
            const unitType = window.fontClampCore?.unitType || 'rem';

            if (isNaN(minRootSize) || isNaN(maxRootSize)) {
                console.error('❌ Invalid root size values in updatePreview');
                return;
            }

            const activeTab = window.fontClampCore?.activeTab || 'class';

            sizes.forEach((size, index) => {
                const nameValue = this.getSizeDisplayName(size, activeTab);
                const minSize = size.min || this.constants.DEFAULT_MIN_ROOT_SIZE;
                const maxSize = size.max || this.constants.DEFAULT_MAX_ROOT_SIZE;

                let minSizePx, maxSizePx;
                if (unitType === 'rem') {
                    minSizePx = minSize * minRootSize;
                    maxSizePx = maxSize * maxRootSize;
                } else {
                    minSizePx = minSize;
                    maxSizePx = maxSize;
                }

                const lineHeight = size.lineHeight || this.constants.DEFAULT_LINE_HEIGHT;

                const minTextHeight = minSizePx * lineHeight;
                const maxTextHeight = maxSizePx * lineHeight;
                const unifiedRowHeight = Math.max(minTextHeight, maxTextHeight) + 16;

                const minRow = this.createPreviewRow(nameValue, minSizePx, 'px', lineHeight, unifiedRowHeight, size.id, index);
                const maxRow = this.createPreviewRow(nameValue, maxSizePx, 'px', lineHeight, unifiedRowHeight, size.id, index);

                this.addSynchronizedHover(minRow, maxRow);

                previewMin.appendChild(minRow);
                previewMax.appendChild(maxRow);
            });

        } catch (error) {
            console.error('❌ Preview update error:', error);
        }
    }

    createPreviewRow(nameValue, fontSize, unitType, lineHeight, rowHeight, sizeId, index) {
        const row = document.createElement('div');
        row.className = 'preview-row';
        row.dataset.sizeId = sizeId;
        row.dataset.index = index;

        row.style.cssText = `
height: ${rowHeight}px;
display: flex;
align-items: flex-start;
justify-content: center;
margin-bottom: 4px;
overflow: visible;
position: relative;
box-sizing: border-box;
padding: 8px 8px 12px 8px;
cursor: pointer;
transition: background-color 0.2s ease;
`;

        const text = document.createElement('div');
        text.textContent = nameValue;

        const fontSizeValue = `${fontSize}px`;

        text.style.cssText = `
font-family: var(--preview-font, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif);
font-size: ${fontSizeValue};
line-height: ${lineHeight};
font-weight: 500;
color: #1f2937;
text-align: center;
white-space: nowrap;
overflow: visible;
max-width: 100%;
box-sizing: border-box;
margin: 0;
width: 100%;
padding-top: 4px;
`;

        row.addEventListener('click', () => {
            this.highlightDataTableRow(sizeId, index);
            this.highlightPreviewRows(sizeId);
        });

        row.appendChild(text);
        return row;
    }

    highlightDataTableRow(sizeId, index) {
        document.querySelectorAll('.size-row.selected').forEach(row => {
            row.classList.remove('selected');
        });

        const dataTableRow = document.querySelector(`.size-row[data-id="${sizeId}"]`);
        if (dataTableRow) {
            dataTableRow.classList.add('selected');
            dataTableRow.scrollIntoView({
                behavior: 'smooth',
                block: 'nearest'
            });
        }
    }

    highlightPreviewRows(sizeId) {
        document.querySelectorAll('.preview-row.selected').forEach(row => {
            row.classList.remove('selected');
        });

        document.querySelectorAll(`.preview-row[data-size-id="${sizeId}"]`).forEach(row => {
            row.classList.add('selected');
        });
    }

    addSynchronizedHover(element1, element2) {
        const hoverIn = () => {
            element1.style.backgroundColor = 'rgba(59, 130, 246, 0.1)';
            element2.style.backgroundColor = 'rgba(59, 130, 246, 0.1)';
        };

        const hoverOut = () => {
            element1.style.backgroundColor = 'transparent';
            element2.style.backgroundColor = 'transparent';
        };

        element1.addEventListener('mouseenter', hoverIn);
        element1.addEventListener('mouseleave', hoverOut);
        element2.addEventListener('mouseenter', hoverIn);
        element2.addEventListener('mouseleave', hoverOut);
    }
renderSizes() {
    console.log('🎯 renderSizes() using constants');

    const wrapper = this.elements.sizesTableWrapper;
    if (!wrapper) return;

    const sizes = this.getCurrentSizes();
    const activeTab = window.fontClampCore?.activeTab || 'class';
    const unitType = window.fontClampCore?.unitType || 'rem';

    // FIXED: Adjusted column widths for better fit
    const nameWidth = activeTab === 'vars' ? '90px' : activeTab === 'tag' ? '60px' : '75px';
    const actionWidth = '80px'; // Increased from 60px to fit both buttons

    wrapper.innerHTML = `
        <table class="font-table">
            <thead>
                <tr id="table-header">
                    <th style="width: 24px;">⋮</th>
                    <th style="width: ${nameWidth};">Name</th>
                    <th style="width: 70px;">Min Size</th>
                    <th style="width: 70px;">Max Size</th>
                    <th style="width: 40px;">Hgt</th>
                    <th style="width: ${actionWidth};"></th>
                </tr>
            </thead>
            <tbody id="sizes-table"></tbody>
        </table>
    `;

    const tbody = document.getElementById('sizes-table');

    sizes.forEach((size, index) => {
        const row = document.createElement('tr');
        row.className = 'size-row';
        row.draggable = true;
        row.dataset.id = size.id;
        row.dataset.index = index;

        const nameValue = this.getSizeDisplayName(size, activeTab);

        row.innerHTML = `
            <td class="drag-handle" style="text-align: center; color: #9ca3af; cursor: grab; user-select: none;" 
data-tooltip="Drag to reorder" data-tooltip-position="right">⋮⋮</td>
            <td style="font-weight: 500; overflow: hidden; text-overflow: ellipsis;" title="${nameValue}">${nameValue}</td>
            <td style="text-align: center; font-family: monospace; font-size: 10px;">${this.formatSize(size.min, unitType)}</td>
            <td style="text-align: center; font-family: monospace; font-size: 10px;">${this.formatSize(size.max, unitType)}</td>
            <td style="text-align: center; font-size: 11px;">${size.lineHeight}</td>
            <td style="text-align: center; padding: 2px;">
                <button class="edit-btn" style="color: #3b82f6; background: none; border: none; cursor: pointer; margin-right: 6px; font-size: 13px; padding: 2px;" title="Edit">✎</button>
                <button class="delete-btn" style="color: #ef4444; background: none; border: none; cursor: pointer; font-size: 12px; padding: 2px;" title="Delete">🗑</button>
            </td>
        `;

        this.bindRowEvents(row);
        tbody.appendChild(row);
    });

    this.updateTableHeaders();
    this.updateCSS();
}


    bindRowEvents(row) {
        const editBtn = row.querySelector('.edit-btn');
        if (editBtn) {
            editBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.editSize(parseInt(row.dataset.id));
            });
        }

        const deleteBtn = row.querySelector('.delete-btn');
        if (deleteBtn) {
            deleteBtn.addEventListener('click', (e) => {
                e.stopPropagation();
                this.deleteSize(parseInt(row.dataset.id));
            });
        }

        row.addEventListener('click', (e) => {
            if (e.target.closest('button')) return;

            const sizeId = row.dataset.id;
            const index = row.dataset.index;

            document.querySelectorAll('.size-row.selected').forEach(r => {
                r.classList.remove('selected');
            });

            row.classList.add('selected');
            this.highlightPreviewRows(sizeId);
        });

        this.setupRowDragAndDrop(row);
    }

    setupRowDragAndDrop(row) {
        this.log('Setting up drag for row:', row.dataset.id);

        row.setAttribute('draggable', 'true');
        row.style.cursor = 'move';

        const dragHandle = row.querySelector('.drag-handle');
        if (dragHandle) {
            dragHandle.style.cursor = 'grab';
            dragHandle.style.userSelect = 'none';

            dragHandle.addEventListener('selectstart', (e) => e.preventDefault());

            dragHandle.addEventListener('mousedown', (e) => {
                this.log('Mouse down on drag handle');
                dragHandle.style.cursor = 'grabbing';
            });

            dragHandle.addEventListener('mouseup', () => {
                dragHandle.style.cursor = 'grab';
            });
        }

        row.addEventListener('dragstart', (e) => {
            this.log('DRAGSTART fired for row:', row.dataset.id);

            this.dragState.isDragging = true;
            this.dragState.draggedRow = row;

            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', row.dataset.id);

            row.classList.add('dragging');
        });

        row.addEventListener('dragend', (e) => {
            this.log('DRAGEND fired');

            row.classList.remove('dragging');
            document.querySelectorAll('.drag-over').forEach(r => {
                r.classList.remove('drag-over');
            });

            this.dragState.isDragging = false;
            this.dragState.draggedRow = null;
        });

        row.addEventListener('dragover', (e) => {
            e.preventDefault();

            if (this.dragState.isDragging && this.dragState.draggedRow && this.dragState.draggedRow !== row) {
                document.querySelectorAll('.drag-over').forEach(r => {
                    r.classList.remove('drag-over');
                });

                row.classList.add('drag-over');
                e.dataTransfer.dropEffect = 'move';
            }
        });

        row.addEventListener('dragenter', (e) => {
            e.preventDefault();

            if (this.dragState.isDragging && this.dragState.draggedRow && this.dragState.draggedRow !== row) {
                row.classList.add('drag-over');
            }
        });

        row.addEventListener('dragleave', (e) => {
            e.preventDefault();

            if (!row.contains(e.relatedTarget)) {
                row.classList.remove('drag-over');
            }
        });

        row.addEventListener('drop', (e) => {
            e.preventDefault();
            e.stopPropagation();

            row.classList.remove('drag-over');

            if (this.dragState.draggedRow && this.dragState.draggedRow !== row) {
                const draggedId = this.dragState.draggedRow.dataset.id;
                const targetId = row.dataset.id;

                try {
                    this.reorderSizes(draggedId, targetId);
                    this.log('Reorder completed successfully');
                } catch (error) {
                    console.error('❌ Reorder failed:', error);
                }
            }
        });
    }

    reorderSizes(draggedId, targetId) {
        const sizes = this.getCurrentSizes();
        const draggedIndex = sizes.findIndex(s => s.id == draggedId);
        const targetIndex = sizes.findIndex(s => s.id == targetId);

        if (draggedIndex !== -1 && targetIndex !== -1) {
            const draggedSize = sizes.splice(draggedIndex, 1)[0];
            sizes.splice(targetIndex, 0, draggedSize);

            this.calculateSizes();
            this.renderSizes();
            this.updatePreview();
            this.markDataChanged();
        }
    }

    updateCSS() {
        try {
            const findCSSElements = () => {
                const possibleSelectors = [
                    '#selected-css-output', '.class-code', 'pre.class-code',
                    '.selected-css pre', '.css-output .selected pre', '.class-code pre',
                    '#class-code', '.css-selected', '.selected-css'
                ];

                const generatedSelectors = [
                    '#generated-css-output', '.generated-code', 'pre.generated-code',
                    '.generated-css pre', '.css-output .generated pre', '.generated-code pre',
                    '#generated-code', '.css-generated', '.generated-css'
                ];

                let selectedElement = null;
                let generatedElement = null;

                for (const selector of possibleSelectors) {
                    const el = document.querySelector(selector);
                    if (el) {
                        selectedElement = el;
                        break;
                    }
                }

                for (const selector of generatedSelectors) {
                    const el = document.querySelector(selector);
                    if (el) {
                        generatedElement = el;
                        break;
                    }
                }

                return {
                    selectedElement,
                    generatedElement
                };
            };

            const {
                selectedElement,
                generatedElement
            } = findCSSElements();

            if (selectedElement && generatedElement) {
                this.generateAndUpdateCSS(selectedElement, generatedElement);
            }

            const currentData = {
                classSizes: window.fontClampData?.classSizes || [],
                variableSizes: window.fontClampData?.variableSizes || [],
                tagSizes: window.fontClampData?.tagSizes || [],
                coreInterface: window.fontClampCore
            };

            window.dispatchEvent(new CustomEvent('fontClamp_dataUpdated', {
                detail: currentData
            }));

            window.dispatchEvent(new CustomEvent('fontClampAdvancedReady', {
                detail: {
                    advancedFeatures: this,
                    data: currentData
                }
            }));

        } catch (error) {
            console.error('❌ CSS update error:', error);
        }
    }

    /**
     * ENHANCED: Generate CSS using constants instead of magic numbers
     */
    generateAndUpdateCSS(selectedElement, generatedElement) {
        try {
            const sizes = this.getCurrentSizes();
            const activeTab = window.fontClampCore?.activeTab || 'class';
            const unitType = window.fontClampCore?.unitType || 'rem';

            const generateClampCSS = (minSize, maxSize) => {
                // FIXED: Use constants instead of magic numbers
                const minViewport = parseFloat(this.elements?.minViewportInput?.value ||
                    document.getElementById('min-viewport')?.value || this.constants.DEFAULT_MIN_VIEWPORT);
                const maxViewport = parseFloat(this.elements?.maxViewportInput?.value ||
                    document.getElementById('max-viewport')?.value || this.constants.DEFAULT_MAX_VIEWPORT);

                const minRootSize = parseFloat(this.elements.minRootSizeInput?.value);
                const maxRootSize = parseFloat(this.elements.maxRootSizeInput?.value);
                
                if (isNaN(minRootSize) || isNaN(maxRootSize)) {
                    this.log('❌ Invalid root size value from user Settings inputs');
                    return;
                }
                
                let minValue, maxValue;
                if (unitType === 'rem') {
                    minValue = `${minSize}rem`;
                    maxValue = `${maxSize}rem`;
                } else {
                    minValue = `${minSize}px`;
                    maxValue = `${maxSize}px`;
                }

                const slope = (maxSize - minSize) / (maxViewport - minViewport);
                const intersection = -minViewport * slope + minSize;

                const slopeVw = (slope * 100).toFixed(4);
                const intersectionValue = unitType === 'rem' ?
                    `${intersection.toFixed(4)}rem` : `${intersection.toFixed(4)}px`;

                return `clamp(${minValue}, ${intersectionValue} + ${slopeVw}vw, ${maxValue})`;
            };

            const selectedId = this.getSelectedSizeId();
            const selectedSize = sizes.find(s => s.id === selectedId);

            if (selectedSize && selectedSize.min && selectedSize.max) {
                const clampValue = generateClampCSS(selectedSize.min, selectedSize.max);
                const nameValue = this.getSizeDisplayName(selectedSize, activeTab);

                let selectedCSS = '';
                if (activeTab === 'class') {
                    selectedCSS = `.${nameValue} {\n  font-size: ${clampValue};\n  line-height: ${selectedSize.lineHeight};\n}`;
                } else if (activeTab === 'vars') {
                    selectedCSS = `:root {\n  ${nameValue}: ${clampValue};\n}`;
                } else {
                    selectedCSS = `${nameValue} {\n  font-size: ${clampValue};\n  line-height: ${selectedSize.lineHeight};\n}`;
                }

                selectedElement.textContent = selectedCSS;
            } else {
                selectedElement.textContent = '/* No size selected or calculated */';
            }

            let allCSS = '';

            if (activeTab === 'class') {
                sizes.forEach(size => {
                    if (size.min && size.max) {
                        const clampValue = generateClampCSS(size.min, size.max);
                        allCSS += `.${size.className} {\n  font-size: ${clampValue};\n  line-height: ${size.lineHeight};\n}\n\n`;
                    }
                });
            } else if (activeTab === 'vars') {
                allCSS = ':root {\n';
                sizes.forEach(size => {
                    if (size.min && size.max) {
                        const clampValue = generateClampCSS(size.min, size.max);
                        allCSS += `  ${size.variableName}: ${clampValue};\n`;
                    }
                });
                allCSS += '}';
            } else {
                sizes.forEach(size => {
                    if (size.min && size.max) {
                        const clampValue = generateClampCSS(size.min, size.max);
                        allCSS += `${size.tagName} {\n  font-size: ${clampValue};\n  line-height: ${size.lineHeight};\n}\n\n`;
                    }
                });
            }

            generatedElement.textContent = allCSS || '/* No sizes calculated */';

        } catch (error) {
            console.error('❌ Direct CSS generation error:', error);
        }
    }

    getSelectedSizeId() {
        const activeTab = window.fontClampCore?.activeTab || 'class';
        const baseValue = document.getElementById('base-value')?.value;

        if (!baseValue) return null;

        const sizes = this.getCurrentSizes();
        const selectedSize = sizes.find(size => {
            switch (activeTab) {
                case 'class':
                    return size.className === baseValue;
                case 'vars':
                    return size.variableName === baseValue;
                case 'tag':
                    return size.tagName === baseValue;
            }
        });

        return selectedSize ? selectedSize.id : null;
    }

    updatePreviewFont() {
        const fontUrl = this.elements.previewFontUrlInput?.value;
        const filenameSpan = this.elements.fontFilenameSpan;

        if (fontUrl && fontUrl.trim()) {
            const filename = fontUrl.split('/').pop().split('?')[0] || 'Custom Font';
            if (filenameSpan) {
                filenameSpan.textContent = filename;
            }

            if (this.lastFontStyle) {
                this.lastFontStyle.remove();
            }

            const fontStyle = document.createElement('style');
            fontStyle.textContent = `
                @font-face {
                    font-family: 'PreviewFont';
                    src: url('${fontUrl}') format('woff2');
                    font-display: swap;
                }
                :root {
                    --preview-font: 'PreviewFont', sans-serif;
                }
            `;
            document.head.appendChild(fontStyle);
            this.lastFontStyle = fontStyle;
        } else {
            if (filenameSpan) {
                filenameSpan.textContent = 'Default';
            }
            if (this.lastFontStyle) {
                this.lastFontStyle.remove();
                this.lastFontStyle = null;
            }
        }
    }

    editSize(id) {
        const sizes = this.getCurrentSizes();
        const size = sizes.find(s => s.id == id);
        if (!size) return;

        this.editingId = id;

        const modal = document.getElementById('edit-modal');
        const nameInput = document.getElementById('edit-name');
        const nameField = document.getElementById('name-field');
        const lineHeightInput = document.getElementById('edit-line-height');

        if (!modal || !nameInput || !lineHeightInput) return;

        const activeTab = window.fontClampCore?.activeTab || 'class';
        const nameValue = this.getSizeDisplayName(size, activeTab);

        nameInput.value = nameValue;
        lineHeightInput.value = size.lineHeight;

        nameField.style.display = activeTab === 'tag' ? 'none' : 'block';

        const header = modal.querySelector('.fcc-modal-header');
        if (header) {
            header.firstChild.textContent = `Edit ${nameValue}`;
        }

        modal.classList.add('show');

        setTimeout(() => {
            (activeTab === 'tag' ? lineHeightInput : nameInput).focus();
        }, 100);
    }

    saveEdit() {
        if (!this.editingId) return;

        const sizes = this.getCurrentSizes();
        const size = sizes.find(s => s.id == this.editingId);
        if (!size) return;

        const nameInput = document.getElementById('edit-name');
        const lineHeightInput = document.getElementById('edit-line-height');
        const activeTab = window.fontClampCore?.activeTab || 'class';

        const newName = nameInput.value.trim();
        const newLineHeight = parseFloat(lineHeightInput.value);

        if (!newName && activeTab !== 'tag') {
            this.showFieldError(nameInput, 'Name cannot be empty');
            return;
        }

        // FIXED: Use constants for validation instead of magic numbers
        const minLineHeight = this.constants.LINE_HEIGHT_RANGE ? this.constants.LINE_HEIGHT_RANGE[0] : 0.8;
        const maxLineHeight = this.constants.LINE_HEIGHT_RANGE ? this.constants.LINE_HEIGHT_RANGE[1] : 3.0;

        if (isNaN(newLineHeight) || newLineHeight < minLineHeight || newLineHeight > maxLineHeight) {
            this.showFieldError(lineHeightInput, `Line height must be between ${minLineHeight} and ${maxLineHeight}`);
            return;
        }

        if (activeTab !== 'tag') {
            const isDuplicate = sizes.some(s => {
                if (s.id === this.editingId) return false;
                const existingName = this.getSizeDisplayName(s, activeTab);
                return existingName === newName;
            });

            if (isDuplicate) {
                this.showFieldError(nameInput, 'A size with this name already exists');
                return;
            }
        }

        if (activeTab === 'class') {
            size.className = newName;
        } else if (activeTab === 'vars') {
            size.variableName = newName;
        }
        size.lineHeight = newLineHeight;

        this.updateBaseValueOptions();
        this.renderSizes();
        this.updatePreview();
        this.markDataChanged();
        this.closeModal();
    }

    closeModal() {
        const modal = document.getElementById('edit-modal');
        if (modal) {
            modal.classList.remove('show');
        }
        this.editingId = null;
    }

    deleteSize(id) {
        if (confirm('Delete this size?')) {
            const sizes = this.getCurrentSizes();
            const index = sizes.findIndex(s => s.id == id);
            if (index !== -1) {
                sizes.splice(index, 1);
                this.renderSizes();
                this.updatePreview();
                this.markDataChanged();
            }
        }
    }

    /**
     * ENHANCED: Add new size using constants for defaults
     */
    addNewSize() {
        const sizes = this.getCurrentSizes();
        const activeTab = window.fontClampCore?.activeTab || 'class';
        const nextId = Date.now();

        const getNextCustomNumber = (sizes, activeTab) => {
            const existingNumbers = sizes
                .map(size => {
                    let name = '';
                    switch (activeTab) {
                        case 'class':
                            name = size.className || '';
                            break;
                        case 'vars':
                            name = size.variableName || '';
                            break;
                        case 'tag':
                            return 0;
                    }

                    const match = name.match(/^(?:custom-|--fs-custom-)(\d+)$/);
                    return match ? parseInt(match[1]) : 0;
                })
                .filter(num => num > 0);

            return existingNumbers.length > 0 ? Math.max(...existingNumbers) + 1 : 1;
        };

        const customNumber = getNextCustomNumber(sizes, activeTab);

        // FIXED: Use constants for new size defaults
        const newSize = {
            id: nextId,
            min: this.constants.DEFAULT_MIN_ROOT_SIZE,
            max: this.constants.DEFAULT_MAX_ROOT_SIZE,
            lineHeight: this.constants.DEFAULT_LINE_HEIGHT
        };

        switch (activeTab) {
            case 'class':
                newSize.className = `custom-${customNumber}`;
                break;
            case 'vars':
                newSize.variableName = `--fs-custom-${customNumber}`;
                break;
            case 'tag':
                newSize.tagName = 'span';
                break;
        }

        sizes.push(newSize);

        this.updateBaseValueOptions();

        setTimeout(() => {
            const baseValueSelect = this.elements.baseValueSelect;

            if (baseValueSelect && baseValueSelect.options.length > 0) {
                if (!baseValueSelect.value || sizes.length === 1) {
                    const newEntryValue = activeTab === 'class' ? newSize.className :
                        activeTab === 'vars' ? newSize.variableName : newSize.tagName;

                    for (let i = 0; i < baseValueSelect.options.length; i++) {
                        if (baseValueSelect.options[i].value === newEntryValue) {
                            baseValueSelect.selectedIndex = i;
                            break;
                        }
                    }
                }
            }

            this.calculateSizes();
            this.renderSizes();
            this.updatePreview();
            this.markDataChanged();
        }, 50);
    }

    resetDefaults() {
        if (confirm('Reset all sizes to defaults? This will lose any custom changes.')) {
            const activeTab = window.fontClampCore?.activeTab || 'class';

            switch (activeTab) {
                case 'class':
                    window.fontClampData.classSizes = this.getDefaultClassSizes();
                    break;
                case 'vars':
                    window.fontClampData.variableSizes = this.getDefaultVariableSizes();
                    break;
                case 'tag':
                    window.fontClampData.tagSizes = this.getDefaultTagSizes();
                    break;
            }

            this.updateBaseValueOptions();
            this.calculateSizes();
            this.renderSizes();
            this.updatePreview();
            this.markDataChanged();
        }
    }

    clearSizes() {
        if (confirm('Clear all sizes?')) {
            const sizes = this.getCurrentSizes();
            sizes.length = 0;

            this.updateBaseValueOptions();
            this.renderSizes();
            this.updatePreview();
            this.updateCSS();
            this.markDataChanged();
        }
    }

    updateSettings() {
        this.calculateSizes();
        this.renderSizes();
        this.updatePreview();
        this.markDataChanged();
    }

    markDataChanged() {
        this.dataChanged = true;

        const autosaveEnabled = this.elements.autosaveToggle?.checked !== false;
        if (autosaveEnabled) {
            this.updateAutosaveStatus('saving');
            setTimeout(() => this.saveToWordPress(), 1000);
        }
    }

    updateAutosaveStatus(status) {
        const statusEl = this.elements.autosaveStatus;
        const iconEl = this.elements.autosaveIcon;
        const textEl = this.elements.autosaveText;

        if (!statusEl || !iconEl || !textEl) return;

        statusEl.className = `autosave-status ${status}`;

        switch (status) {
            case 'saving':
                iconEl.innerHTML = '<span class="spinner"></span>';
                textEl.textContent = 'Saving...';
                break;
            case 'saved':
                iconEl.textContent = '✓';
                textEl.textContent = 'Saved';
                setTimeout(() => this.updateAutosaveStatus('idle'), 2000);
                break;
            case 'error':
                iconEl.textContent = '✗';
                textEl.textContent = 'Error';
                break;
            default:
                iconEl.textContent = '💾';
                textEl.textContent = 'Ready';
        }
    }

    saveToWordPress() {
        if (!window.fontClampAjax) {
            console.error('AJAX configuration not available');
            this.updateAutosaveStatus('error');
            return;
        }

        const formData = new FormData();
        formData.append('action', 'save_font_clamp_sizes');
        formData.append('nonce', window.fontClampAjax.nonce);
        formData.append('class_sizes', JSON.stringify(window.fontClampData.classSizes || []));
        formData.append('variable_sizes', JSON.stringify(window.fontClampData.variableSizes || []));
        formData.append('tag_sizes', JSON.stringify(window.fontClampData.tagSizes || []));

        fetch(window.fontClampAjax.ajaxurl, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.updateAutosaveStatus('saved');
                } else {
                    console.error('Save failed:', data.data);
                    this.updateAutosaveStatus('error');
                }
            })
            .catch(error => {
                console.error('Save error:', error);
                this.updateAutosaveStatus('error');
            });
    }

    getCurrentSizes() {
        const activeTab = window.fontClampCore?.activeTab || 'class';

        let sizes = [];
        switch (activeTab) {
            case 'class':
                sizes = window.fontClampData?.classSizes || [];
                break;
            case 'vars':
                sizes = window.fontClampData?.variableSizes || [];
                break;
            case 'tag':
                sizes = window.fontClampData?.tagSizes || [];
                break;
            default:
                sizes = [];
        }

        if (sizes.length === 0) {
            this.log('No sizes found, using defaults for:', activeTab);
            switch (activeTab) {
                case 'class':
                    sizes = this.getDefaultClassSizes();
                    if (window.fontClampData) {
                        window.fontClampData.classSizes = sizes;
                    }
                    break;
                case 'vars':
                    sizes = this.getDefaultVariableSizes();
                    if (window.fontClampData) {
                        window.fontClampData.variableSizes = sizes;
                    }
                    break;
                case 'tag':
                    sizes = this.getDefaultTagSizes();
                    if (window.fontClampData) {
                        window.fontClampData.tagSizes = sizes;
                    }
                    break;
            }
        }

        return sizes;
    }

    getSizeDisplayName(size, activeTab) {
        switch (activeTab) {
            case 'class':
                return size.className || '';
            case 'vars':
                return size.variableName || '';
            case 'tag':
                return size.tagName || '';
            default:
                return '';
        }
    }

    formatSize(value, unitType) {
        if (!value) return '—';
        if (unitType === 'px') {
            return `${Math.round(value)} ${unitType}`;
        }
        return `${value.toFixed(3)} ${unitType}`;
    }

    showFieldError(field, message) {
        field.classList.add('error');
        field.focus();
        alert(message);
        setTimeout(() => field.classList.remove('error'), 3000);
    }

    showError(message) {
        console.error(message);
    }

    /**
     * ENHANCED: Default sizes using constants instead of magic numbers
     */
    getDefaultClassSizes() {
        return [
            {id: 1, className: 'xxxlarge', lineHeight: this.constants.DEFAULT_HEADING_LINE_HEIGHT},
            {id: 2, className: 'xxlarge', lineHeight: this.constants.DEFAULT_HEADING_LINE_HEIGHT},
            {id: 3, className: 'xlarge', lineHeight: this.constants.DEFAULT_HEADING_LINE_HEIGHT},
            {id: 4, className: 'large', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 5, className: 'medium', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 6, className: 'small', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 7, className: 'xsmall', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 8, className: 'xxsmall', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT}
        ];
    }

    getDefaultVariableSizes() {
        return [
            {id: 1, variableName: '--fs-xxxl', lineHeight: this.constants.DEFAULT_HEADING_LINE_HEIGHT},
            {id: 2, variableName: '--fs-xxl', lineHeight: this.constants.DEFAULT_HEADING_LINE_HEIGHT},
            {id: 3, variableName: '--fs-xl', lineHeight: this.constants.DEFAULT_HEADING_LINE_HEIGHT},
            {id: 4, variableName: '--fs-lg', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 5, variableName: '--fs-md', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 6, variableName: '--fs-sm', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 7, variableName: '--fs-xs', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 8, variableName: '--fs-xxs', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT}
        ];
    }

    getDefaultTagSizes() {
        return [
            {id: 1, tagName: 'h1', lineHeight: this.constants.DEFAULT_HEADING_LINE_HEIGHT},
            {id: 2, tagName: 'h2', lineHeight: this.constants.DEFAULT_HEADING_LINE_HEIGHT},
            {id: 3, tagName: 'h3', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 4, tagName: 'h4', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 5, tagName: 'h5', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 6, tagName: 'h6', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT},
            {id: 7, tagName: 'p', lineHeight: this.constants.DEFAULT_BODY_LINE_HEIGHT}
        ];
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func.apply(this, args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
}

window.fontClampAdvanced = new FontClampAdvanced();

</script>

    <?php
    }

    /**
     * ENHANCED: Initialize JavaScript data with proper constants
     */
    public function init_javascript()
    {
        $constants = $this->getCalculatorConstants();
        
        $localized_data = [
            'classSizes' => $this->data['classSizes'],
            'variableSizes' => $this->data['variableSizes'],
            'tagSizes' => $this->data['tagSizes'],
            'settings' => $this->settings
        ];

        ?>
        <script>
            console.log('🎯 Magic Number Fix: Segment C - Initializing JavaScript data with complete constants...');
            
            function initializeFontClampData() {
                if (typeof window.fontClampAjax !== 'undefined' && window.fontClampAjax.data) {
                    window.fontClampData = window.fontClampAjax.data;
                    console.log('✅ Magic Number Fix: Using data from Segment A wp_localize_script');
                    console.log('   Available constants:', window.fontClampAjax.constants ? Object.keys(window.fontClampAjax.constants) : 'None');
                    return true;
                } else {
                    window.fontClampData = <?php echo json_encode($localized_data); ?>;
                    console.log('⚠️ Magic Number Fix: Using fallback data from Segment C');
                    return true;
                }
            }

            function ensureAjaxConfig() {
                if (typeof window.fontClampAjax === 'undefined') {
                    window.fontClampAjax = {
                        ajaxurl: '<?php echo admin_url('admin-ajax.php'); ?>',
                        nonce: '<?php echo wp_create_nonce('font_clamp_advanced_nonce'); ?>',
                        defaults: {
                            minRootSize: <?php echo $constants['DEFAULT_MIN_ROOT_SIZE']; ?>,    
                            maxRootSize: <?php echo $constants['DEFAULT_MAX_ROOT_SIZE']; ?>, 
                            minViewport: <?php echo $constants['DEFAULT_MIN_VIEWPORT']; ?>, 
                            maxViewport: <?php echo $constants['DEFAULT_MAX_VIEWPORT']; ?> 
                        },
                        // FIXED: Add complete constants to fallback config
                        constants: {
                            DEFAULT_MIN_ROOT_SIZE: <?php echo $constants['DEFAULT_MIN_ROOT_SIZE']; ?>,
                            DEFAULT_MAX_ROOT_SIZE: <?php echo $constants['DEFAULT_MAX_ROOT_SIZE']; ?>,
                            DEFAULT_MIN_VIEWPORT: <?php echo $constants['DEFAULT_MIN_VIEWPORT']; ?>,
                            DEFAULT_MAX_VIEWPORT: <?php echo $constants['DEFAULT_MAX_VIEWPORT']; ?>,
                            DEFAULT_LINE_HEIGHT: <?php echo $constants['DEFAULT_LINE_HEIGHT']; ?>,
                            DEFAULT_HEADING_LINE_HEIGHT: <?php echo $constants['DEFAULT_HEADING_LINE_HEIGHT']; ?>,
                            DEFAULT_BODY_LINE_HEIGHT: <?php echo $constants['DEFAULT_BODY_LINE_HEIGHT']; ?>,
                            BROWSER_DEFAULT_FONT_SIZE: <?php echo $constants['BROWSER_DEFAULT_FONT_SIZE']; ?>,
                            CSS_UNIT_CONVERSION_BASE: <?php echo $constants['CSS_UNIT_CONVERSION_BASE']; ?>
                        }
                    };
                    console.log('🔧 Magic Number Fix: Created fallback fontClampAjax config with complete constants');
                }
            }

            ensureAjaxConfig();
            const dataInitialized = initializeFontClampData();

            if (dataInitialized) {
                console.log('✅ Magic Number Fix: Font Clamp data initialization complete with constants');
                
                window.dispatchEvent(new CustomEvent('fontClampDataReady', {
                    detail: {
                        data: window.fontClampData,
                        ajax: window.fontClampAjax
                    }
                }));
            } else {
                console.error('❌ Magic Number Fix: Font Clamp data initialization failed');
            }
        </script>
        <?php
    }

    // Rest of the methods remain the same but use constants where applicable

    public function handle_ajax_save()
    {
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'font_clamp_advanced_nonce')) {
            wp_send_json_error(['message' => 'Security check failed']);
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
        }

        try {
            $class_sizes = $this->sanitize_sizes_data($_POST['class_sizes'] ?? '[]');
            $variable_sizes = $this->sanitize_sizes_data($_POST['variable_sizes'] ?? '[]');
            $tag_sizes = $this->sanitize_sizes_data($_POST['tag_sizes'] ?? '[]');

            $result = $this->save_sizes_to_database($class_sizes, $variable_sizes, $tag_sizes);

            if ($result) {
                wp_send_json_success(['message' => 'Sizes saved successfully']);
            } else {
                wp_send_json_error(['message' => 'Failed to save sizes']);
            }
        } catch (Exception $e) {
            $this->log_error('AJAX Save Error', $e);
            wp_send_json_error(['message' => 'Server error occurred']);
        }
    }

    /**
     * ENHANCED: Sanitize sizes data using proper constants
     */
    private function sanitize_sizes_data($json_data)
    {
        $constants = $this->getCalculatorConstants();
        $data = json_decode(stripslashes($json_data), true);

        if (!is_array($data)) {
            return [];
        }

        return array_map(function ($size) use ($constants) {
            return [
                'id' => (int) ($size['id'] ?? 0),
                'className' => sanitize_html_class($size['className'] ?? ''),
                'variableName' => $this->sanitize_css_variable($size['variableName'] ?? ''),
                'tagName' => sanitize_key($size['tagName'] ?? ''),
                'min' => $this->sanitize_float(
                    $size['min'] ?? $constants['DEFAULT_MIN_ROOT_SIZE'],
                    $constants['MIN_ROOT_SIZE_RANGE'][0],
                    $constants['MIN_ROOT_SIZE_RANGE'][1]
                ),
                'max' => $this->sanitize_float(
                    $size['max'] ?? $constants['DEFAULT_MAX_ROOT_SIZE'],
                    $constants['MIN_ROOT_SIZE_RANGE'][0],
                    $constants['MIN_ROOT_SIZE_RANGE'][1]
                ),
                'lineHeight' => $this->sanitize_float(
                    $size['lineHeight'] ?? $constants['DEFAULT_LINE_HEIGHT'],
                    $constants['LINE_HEIGHT_RANGE'][0],
                    $constants['LINE_HEIGHT_RANGE'][1]
                ),
            ];
        }, $data);
    }

    private function sanitize_css_variable($variable)
    {
        if (!str_starts_with($variable, '--')) {
            $variable = '--' . $variable;
        }
        return preg_replace('/[^a-zA-Z0-9\-]/', '', $variable);
    }

    /**
     * ENHANCED: Sanitize float with proper range validation
     */
    private function sanitize_float($value, $min = null, $max = null)
    {
        $constants = $this->getCalculatorConstants();
        $value = (float) $value;
        
        if ($min === null && $max === null) {
            $min = $constants['MIN_ROOT_SIZE_RANGE'][0];
            $max = $constants['MIN_ROOT_SIZE_RANGE'][1];
        }
        
        return max($min ?? 0, min($max ?? 999, $value));
    }

    private function save_sizes_to_database($class_sizes, $variable_sizes, $tag_sizes)
    {
        $options = [
            'font_clamp_class_sizes' => $class_sizes,
            'font_clamp_variable_sizes' => $variable_sizes,
            'font_clamp_tag_sizes' => $tag_sizes,
            'font_clamp_last_updated' => current_time('mysql'),
        ];

        $success = true;
        foreach ($options as $option_name => $option_value) {
            if (!update_option($option_name, $option_value)) {
                $success = false;
                $this->log_error("Failed to update option: {$option_name}");
            }
        }

        return $success;
    }

    /**
     * ENHANCED: Get default sizes using constants
     */
    private function get_default_class_sizes()
    {
        $constants = $this->getCalculatorConstants();
        
        return [
            ['id' => 1, 'className' => 'xxxlarge', 'lineHeight' => $constants['DEFAULT_HEADING_LINE_HEIGHT']],
            ['id' => 2, 'className' => 'xxlarge', 'lineHeight' => $constants['DEFAULT_HEADING_LINE_HEIGHT']],
            ['id' => 3, 'className' => 'xlarge', 'lineHeight' => $constants['DEFAULT_HEADING_LINE_HEIGHT']],
            ['id' => 4, 'className' => 'large', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 5, 'className' => 'medium', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 6, 'className' => 'small', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 7, 'className' => 'xsmall', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 8, 'className' => 'xxsmall', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
        ];
    }

    private function get_default_variable_sizes()
    {
        $constants = $this->getCalculatorConstants();
        
        return [
            ['id' => 1, 'variableName' => '--fs-xxxl', 'lineHeight' => $constants['DEFAULT_HEADING_LINE_HEIGHT']],
            ['id' => 2, 'variableName' => '--fs-xxl', 'lineHeight' => $constants['DEFAULT_HEADING_LINE_HEIGHT']],
            ['id' => 3, 'variableName' => '--fs-xl', 'lineHeight' => $constants['DEFAULT_HEADING_LINE_HEIGHT']],
            ['id' => 4, 'variableName' => '--fs-lg', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 5, 'variableName' => '--fs-md', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 6, 'variableName' => '--fs-sm', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 7, 'variableName' => '--fs-xs', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 8, 'variableName' => '--fs-xxs', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
        ];
    }

    private function get_default_tag_sizes()
    {
        $constants = $this->getCalculatorConstants();
        
        return [
            ['id' => 1, 'tagName' => 'h1', 'lineHeight' => $constants['DEFAULT_HEADING_LINE_HEIGHT']],
            ['id' => 2, 'tagName' => 'h2', 'lineHeight' => $constants['DEFAULT_HEADING_LINE_HEIGHT']],
            ['id' => 3, 'tagName' => 'h3', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 4, 'tagName' => 'h4', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 5, 'tagName' => 'h5', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 6, 'tagName' => 'h6', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
            ['id' => 7, 'tagName' => 'p', 'lineHeight' => $constants['DEFAULT_BODY_LINE_HEIGHT']],
        ];
    }

    public function show_dependency_notice()
    {
        echo '<div class="notice notice-warning">
            <p><strong>Font Clamp Calculator Advanced Features:</strong> 
            Running in standalone mode. For full functionality, activate Core Calculator (Segment A) first.</p>
        </div>';
    }

    public function show_error_notice()
    {
        echo '<div class="notice notice-error">
            <p><strong>Font Clamp Calculator:</strong> 
            Advanced features failed to initialize. Check error log for details.</p>
        </div>';
    }

    private function log_error($message, $exception = null)
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            $log_message = '[Font Clamp Advanced] ' . $message;
            if ($exception) {
                $log_message .= ': ' . $exception->getMessage();
            }
            error_log($log_message);
        }
    }
}

if (is_admin()) {
    new FontClampAdvancedFeatures();
}
?>