# Partnership Handoff Document 

## **Continuing Partnership Guidance**

### **Problem-Solving Approach:**
- ✅ Ask "What's your instinct?" before suggesting solutions
- ✅ Build on Jim's WordPress architecture knowledge
- ✅ Explain reasoning behind technical suggestions

### **Proven Technical Collaboration Style:**
- ✅ **PREFERRED**: Small, targeted fixes with specific locations ("At location line X, change Y to Z")
- ✅ **EXCELLENT**: "Find this code... Change to this code..." format
- ✅ **EFFECTIVE**: One method/function replacement per message when needed
- ✅ **ACCEPTABLE**: Complete arrays, single classes, or logical whole units in artifacts
- ✅ **AVOID**: Multiple files, complete segment rewrites (without explicit permission)
- ✅ Each step should be testable independently
- ✅ Maintain existing architecture and patterns

### **Successful Fix Message Format:**
```
**Fix: [Brief description]**

**Location:** Around line X in [section]
**Find:** [exact code to locate]
**Change to:** [exact replacement code]

**Why:** [brief explanation]
**Test:** [how to verify it works]
```

### **Code Quality Requirements:**
- ✅ Complete single method/function replacements only
- ✅ No redundant code - reuse existing methods where possible
- ✅ Self-documenting with clear variable names and comments
- ✅ Follow existing WordPress coding standards
- ✅ Maintain JimRWeb architectural patterns

### **Communication Standards:**
- ✅ Always warn about approaching chat limits
- ✅ Provide integration/testing plans for any changes
- ✅ Explain what changed and why
- ✅ Include rollback instructions for safety
- ✅ **Jim's preferred style**: Single fix messages with "At location point, change **code** with **code**"
- ✅ **Complete code segments**: Any inserted, removed or changed code should be complete and functional
- ✅ **Artifacts for larger code**: If code blocks are too large (> 20 lines), use artifacts for the complete code
- ✅ **No fix instructions in artifacts**: Keep fix instructions in chat; artifacts should be pure code
---
## 🧹 **Code Cleanup Protocol**

### **When Fixes Don't Work:**
- ✅ **Remove unsuccessful attempts** - Don't let CSS/code accumulate from failed approaches
- ✅ **Clean slate is better** - If multiple fixes tried and none work, revert and start fresh
- ✅ **Don't store bad code** - Jim should not save a code file until there's agreement that the problem is fixed
- ✅ **Ctrl+Z is your friend** - Jim can easily revert to clean state before unsuccessful fixes by abandoning the working VS Code edit or Ctrl+Z to clean code
- ✅ **Store fixes** - When a problem is fixed, Jim will save the code to disk (not commit)
- ✅ **Ask Jim to revert** - "Should we revert the unsuccessful changes and try a different approach?"

### **Red Flags for Cleanup:**
- ❌ Multiple CSS rules targeting same element with `!important`
- ❌ Duplicate selectors or conflicting approaches
- ❌ CSS comments like "/* This attempt didn't work */"
- ❌ JavaScript with multiple event listeners doing similar things
- ❌ Experimental code that wasn't cleaned up

### **Cleanup Decision Point:**
**When to suggest cleanup:**
- After 3+ unsuccessful attempts at same fix
- When code has multiple competing approaches
- When approaching chat limit with unsuccessful changes
- When handoff to new chat would benefit from clean slate

**Script for cleanup suggestion:**
"We've tried several approaches that haven't worked. Should we Ctrl+Z back to a clean state and either try a different approach or hand off to a fresh chat with the clean codebase?"

### **Handoff Best Practice:**
Include what was attempted: "Previous Claude tried X, Y, Z approaches for [feature] but unsuccessful - [brief reason why]. Code reverted to clean state. Recommend trying [different approach] instead."

### **Key Learning:** 
Better to have clean, working code than accumulated experimental attempts. Jim's time is valuable - don't make him debug unsuccessful fixes.

---
## 🎯 **MANDATORY: Before Any Code Generation**

### **STOP Protocol**
Before creating ANY artifacts, Claude MUST:
1. ✋ **STOP** and ask: "What's your instinct for the approach?"
2. 🔍 **ANALYZE** if change can be done with "smallest whole unit"
3. 📋 **PRESENT** 2-3 options with clear tradeoffs
4. ⏳ **WAIT** for Jim's approval before generating code
5. 🚨 **EXPLICITLY ASK PERMISSION** if deviating from minimal change rule

### **Exception Protocol**
If Claude believes a larger change is justified:
- **Must state**: "I think this needs a complete [method/class/segment] rewrite because..."
- **Must explain**: Specific technical reasons why incremental won't work
- **Must get approval**: Wait for explicit "yes, do the full rewrite"

---

## 🎓 **Lessons Learned from Chat Success**

### **What Worked Extremely Well:**
- ✅ **Small, targeted fixes** - "Find line X, change Y to Z" approach
- ✅ **Specific line locations** - "Around line 480 in the HTML section"
- ✅ **Exact code matching** - Providing exact text to find and replace
- ✅ **Step-by-step testing** - Test each fix before moving to next
- ✅ **Chat-based fixes** - Keep fix instructions in chat messages, not artifacts
- ✅ **Artifacts for new classes** - Use artifacts for complete new code blocks
- ✅ **Permission-based approach** - Ask before major changes

### **Proven Fix Pattern:**
```
**Issue:** White text not readable in info panels
**Location:** Around line 480 in HTML section
**Find:** style="color: #FAF9F6;"
**Change to:** style="color: var(--jimr-text);"
**Result:** ✅ Text becomes readable brown color
```

### **When Large Changes Are Justified:**
- ✅ Jim explicitly requests major refactoring
- ✅ Current code is fundamentally broken
- ✅ Security vulnerabilities require immediate fixes
- ✅ Jim says "I want cleaner code, feed it to me!"
- ✅ **New functionality integration** (like complete Phase 3 class integration)

### **When to Stay Incremental:**
- ✅ Bug fixes (like text color issues)
- ✅ Small feature additions
- ✅ Performance improvements
- ✅ Style/CSS adjustments
- ✅ Single method improvements

### **Red Flags - Don't Do This:**
- ❌ Generate complete file rewrites without asking
- ❌ Assume interconnected changes require massive artifacts
- ❌ Skip the "What's your instinct?" question
- ❌ Provide solutions without explaining tradeoffs
- ❌ Put fix instructions inside artifacts

---

## 📋 **Standard Workflow - PROVEN EFFECTIVE**

### **Step 1: Analysis**
- Understand the request
- Identify minimal change approach
- Consider if larger change might be better

### **Step 2: Options Presentation**  
"What's your instinct? I see 3 approaches:
1. **Minimal**: Change just the problematic line/method [tradeoffs]
2. **Moderate**: Update the whole section/class [tradeoffs] 
3. **Complete**: Rewrite for better architecture [tradeoffs]"

### **Step 3: Implementation**
- Wait for Jim's choice
- **For small fixes**: Provide exact "Find X, change to Y" instructions
- **For larger code**: Create artifact with complete functional code
- Include testing/integration steps

### **Step 4: Safety**
- Provide rollback instructions
- Explain what changed
- Include verification steps

---

## 🚨 **Chat Limit Management**

### **Monitor Token Usage:**
- Warn at ~80% capacity
- Suggest new chat continuation
- Provide clear handoff instructions

### **Handoff Template:**
"Continue [project name] [specific task]. Previous Claude provided [specific deliverables]. Current status: [where we left off]. Need: [next steps]."

---

## 💎 **Jim's Priorities (In Order)**
1. **Good, clean, understandable, refactorable code**
2. **Reliable, tested functionality** 
3. **WordPress best practices**
4. **Professional user experience**
5. **Performance and security**

---

## 🏆 **Phase 3 Success Metrics Met**
- ✅ Jim could test each change independently
- ✅ Changes were small enough to understand quickly
- ✅ Code quality improved with each iteration
- ✅ No broken functionality during integration
- ✅ Clear path forward always available
- ✅ **Perfect working relationship established**

---

## 🎯 **Phase 4 Approach Recommendation**

Based on Phase 3 success, continue the **small, targeted fixes approach**:

1. **Start with smallest copy button addition**
2. **Test that it appears correctly**
3. **Add basic clipboard functionality** 
4. **Test that it copies correctly**
5. **Add notifications with small fixes**
6. **Test notification appearance**
7. **Add keyboard shortcuts incrementally**
8. **Polish and refine**

**Key: Each step should be a small, testable change that Jim can verify works before proceeding.**

---

**Remember**: Jim has 50+ years experience and excellent instincts. Trust his process, ask his opinion, and deliver exactly what he approves. The Phase 3 approach of small, targeted fixes with specific locations worked perfectly - continue this proven method!